/*
 * uploadFile.java
 * Creates GUI to upload the Attribute Relations file
 *
 * Created on 18-Dec-2016, 21:40:58
 */

package frames;

import java.awt.Color;
import java.awt.FileDialog;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import org.apache.commons.io.FileUtils;

/**
 *
 * @author DeGod
 */
public class uploadFile extends javax.swing.JFrame implements Runnable {

    String filePath;
    Thread t;
    String myDocumentPath = System.getProperty("user.home") + "\\Documents\\AIS\\";
    int lines;

    public uploadFile() {
        t = new Thread(this);
        initComponents();
        setTitle("AIS - Upload an Attribute Relation file");
        setLocationRelativeTo(null);
        setResizable(false);
        setIconImage(new ImageIcon("src/imgs/aisFav.png").getImage());
        uploadPath.setBorder(BorderFactory.createBevelBorder(15));
        uploadPath.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        uploadPath.setText("Choose a file...");
    }

    public void run(){
        //  Runs the simulation for the progressBar status
        try{
            int pBar = 1;
            while(true){
                t.sleep(0);
                if((lines % 1000) == 0){
                    pBar++;
                    if(pBar == 100){
                        uploadProgress.setValue(pBar);
                        uploadProgress.setForeground(new Color(148, 166, 124));
                        uploadProgress.setFont(new Font("Verdana", Font.BOLD, 16));
                        uploadProgress.setString(pBar+"% Upload Completed!");
                        t.sleep(3000);
                        preprocess db = new preprocess();
                        db.setVisible(true);
                        dispose();
                    }else{
                        uploadProgress.setValue(pBar);
                        uploadProgress.setForeground(new Color(86, 13, 3));
                        uploadProgress.setFont(new Font("Verdana", Font.BOLD, 16));
                        uploadProgress.setString(pBar+"% still uploading...");
                    }
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        uploadPath = new javax.swing.JTextField();
        browseBtn = new javax.swing.JLabel();
        uploadBtn = new javax.swing.JLabel();
        uploadProgress = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(40, 42, 43));

        jLabel1.setFont(new java.awt.Font("Nirmala UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Upload an Attribute Relation file");

        uploadPath.setEditable(false);
        uploadPath.setText("jTextField1");
        uploadPath.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                uploadPathMouseClicked(evt);
            }
        });

        browseBtn.setBackground(new java.awt.Color(148, 166, 124));
        browseBtn.setFont(new java.awt.Font("Corbel", 1, 21));
        browseBtn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        browseBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/browse.png"))); // NOI18N
        browseBtn.setText("Browse");
        browseBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        browseBtn.setOpaque(true);
        browseBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                browseBtnMouseClicked(evt);
            }
        });

        uploadBtn.setFont(new java.awt.Font("Tw Cen MT", 1, 24));
        uploadBtn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        uploadBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/upload.png"))); // NOI18N
        uploadBtn.setText("Upload");
        uploadBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        uploadBtn.setOpaque(true);
        uploadBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                uploadBtnMouseClicked(evt);
            }
        });

        uploadProgress.setString("");
        uploadProgress.setStringPainted(true);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(48, Short.MAX_VALUE)
                .addComponent(uploadPath, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(browseBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(156, 156, 156)
                .addComponent(uploadBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(158, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addComponent(uploadProgress, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(63, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addComponent(jLabel1)
                .addContainerGap(62, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(browseBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(uploadPath, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE))
                .addGap(36, 36, 36)
                .addComponent(uploadBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(uploadProgress, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void uploadBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_uploadBtnMouseClicked
        // Does the upload function for the app (converting the file to "original.arff")...
        File fileNS = new File(myDocumentPath+"original.arff");
        if(fileNS.exists()) {
            fileNS.delete();
        }
        File fileN = new File(myDocumentPath+uploadPath.getText());
        if(fileN.exists()) {
            fileN.delete();
        }
        if(uploadPath.getText().equals("Choose a file...") || filePath.trim().isEmpty() || filePath==null
                || filePath.trim().equalsIgnoreCase("") || uploadPath.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null, "You have to choose a file to upload!", "Error uploading .arff file", 1,
                    new ImageIcon("src/imgs/upload.png"));
        }else{
            t.start();
            File src = new File(filePath);
            double bytes = src.length();
            double kilobytes = (bytes / 1024);

            if(kilobytes > 50){
                JOptionPane.showMessageDialog(null, "We are shortening this file for optimization purpose!",
                        "File too Large", 1, new ImageIcon("src/imgs/upload.png"));
                File dest = new File(myDocumentPath+"original.arff");
                try {
                    BufferedReader br = new BufferedReader(new FileReader(src));
                    BufferedWriter bw = new BufferedWriter(new FileWriter(dest));
                    String line; lines = 0;

                    while ((line = br.readLine()) != null && lines < 100000) {
                        lines++;
                        if (line.startsWith("%")) {
                            continue;
                        } else {
                            bw.append("\n"+line);
                        }
                    }
                    bw.close();
                    br.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }else{
                File dest = new File(myDocumentPath+"original.arff");
                try {
                    BufferedReader br = new BufferedReader(new FileReader(src));
                    BufferedWriter bw = new BufferedWriter(new FileWriter(dest));
                    String line;

                    while ((line = br.readLine()) != null) {
                        if (line.startsWith("%")) {
                            continue;
                        } else {
                            bw.append("\n"+line);
                        }
                    }
                    bw.close();
                    br.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }//GEN-LAST:event_uploadBtnMouseClicked

    private void browseBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_browseBtnMouseClicked
        // Does the browsing of the .txt or .arff file...
        FileDialog fd = new FileDialog(this, "Attribute Relation file upload", FileDialog.LOAD);
        fd.setFile("*.txt;*.arff;");
        fd.setVisible(true);
        filePath = fd.getDirectory()+fd.getFile();

        uploadPath.setText(fd.getFile());
        System.out.println(filePath);

        // Delete Files
        File dir = new File(myDocumentPath);
        if(!dir.exists()){
            dir.mkdir();
        }
        File fileO = new File(myDocumentPath+"original.arff");
        if(fileO.exists()) {
            fileO.delete();
        }
    }//GEN-LAST:event_browseBtnMouseClicked

    private void uploadPathMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_uploadPathMouseClicked
        // Picks the actionPerformed by the browse button...
        browseBtnMouseClicked(evt);
    }//GEN-LAST:event_uploadPathMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel browseBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel uploadBtn;
    private javax.swing.JTextField uploadPath;
    private javax.swing.JProgressBar uploadProgress;
    // End of variables declaration//GEN-END:variables

}
