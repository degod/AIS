/*
 * geneOptimize.java
 * Does the:
 *  ==> Filter (Filters the original file to get only data)
 *  ==> Selection (Permutates 2 datums to be analyzed)
 *  ==> CrossOver (Carries out a uniform CrossOver Genetic Algorithm on selected data)
 *  ==> Mutation (Carries out a Mutation Genetic Algorithm on the offsprings of selected data)
 *  ==> Acceptance (Collates all offsprings into a file - GA-acted.arff)
 * ... on the original.arff to produce the "gaFile.arff"
 *
 * Created on 22-Dec-2016, 10:04:58
 */
package frames;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author DeGod
 */
public class geneOptimize {

    String ref1, ref2, ref3, ref4, ref5;
    int rowTrack[] = new int[0];// posArr[];
    String myDocumentPath = System.getProperty("user.home") + "\\Documents\\AIS\\";

    public void filter() {
        File file = new File(myDocumentPath+"kddminiX.arff");
        File fileX = new File(myDocumentPath+"filtered.arff");
        if(fileX.exists() && !fileX.isDirectory()) {
            // Delete file to recreate
            fileX.delete();
        }
        fileX = new File(myDocumentPath+"filtered.arff");
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileX));
            String line;
            while ((line = br.readLine()) != null) {
                // process the line.
                if (line.startsWith("%")) {
                    continue;
                } else {
                    if (line.startsWith("@relation")) {
                        continue;
                    } else if (line.startsWith("@attribute")) {
                        continue;
                    } else if (line.startsWith("@data")) {
                        continue;
                    } else {
                        if (!line.trim().equals("")) {
                            if (!line.trim().equals("")) {
                                bw.append("\n" + line);
                            }
                            continue;
                        }
                    }
                }
            }
            bw.close();
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void selectData(int posArr[]) {
        filter();
        File fileXi = new File(myDocumentPath+"gaFilter.arff");
        if(fileXi.exists() && !fileXi.isDirectory()) {
            // Delete file to recreate
            fileXi.delete();
        }
        for (int z = 0; z < 50; z++) {
            File fileX = new File(myDocumentPath+"filtered.arff");
            try {
                BufferedReader br = new BufferedReader(new FileReader(fileX));
                String line;
                int totalLines = 0;
                while ((line = br.readLine()) != null) {
                    if (!line.trim().equals("")) {
                        totalLines += 1;
                    }
                }

                int specLine = randLine(totalLines);
                String data1 = readSpecLine(specLine, myDocumentPath+"filtered.arff");
                specLine += 1;
                if(specLine > totalLines){
                    specLine -= randInt(2, 9);
                }
                String data2 = readSpecLine(specLine, myDocumentPath+"filtered.arff");
                specLine += 1;
                if(specLine > totalLines){
                    specLine -= randInt(2, 9);
                }
                String data3 = readSpecLine(specLine, myDocumentPath+"filtered.arff");
                specLine += 1;
                if(specLine > totalLines){
                    specLine -= randInt(2, 9);
                }
                String data4 = readSpecLine(specLine, myDocumentPath+"filtered.arff");
                specLine += 1;
                if(specLine > totalLines){
                    specLine -= randInt(2, 9);
                }
                String data5 = readSpecLine(specLine, myDocumentPath+"filtered.arff");

                crossOverData(data1, data2, data3, data4, data5, posArr);
                br.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        acceptData();
    }

    public void crossOverData(String data1, String data2, String data3, String data4, String data5, int posArr[]) {
        //  Performing "Uniform CrossOver" on selected data
        data1 = data1.replaceAll(",", " ");
        data2 = data2.replaceAll(",", " ");
        data3 = data3.replaceAll(",", " ");
        data4 = data4.replaceAll(",", " ");
        data5 = data5.replaceAll(",", " ");
        String arr1[] = data1.split(" ");
        String arr2[] = data2.split(" ");
        String arr3[] = data3.split(" ");
        String arr4[] = data4.split(" ");
        String arr5[] = data5.split(" ");
        
        for(int i = 0; i < arr1.length; i++){
            if(i == 0)
                ref1 = arr1[0];
            else{
                String[] arr = {arr1[i], arr2[i], arr3[i], arr4[i], arr5[i]};
                ref1 = ref1 + "," +arr[new Random().nextInt(arr.length)];
            }
        }
        for(int i = 0; i < arr1.length; i++){
            if(i == 0)
                ref2 = arr2[0];
            else{
                String[] arr = {arr1[i], arr2[i], arr3[i], arr4[i], arr5[i]};
                ref2 = ref2 + "," +arr[new Random().nextInt(arr.length)];
            }
        }
        for(int i = 0; i < arr1.length; i++){
            if(i == 0)
                ref3 = arr3[0];
            else{
                String[] arr = {arr1[i], arr2[i], arr3[i], arr4[i], arr5[i]};
                ref3 = ref3 + "," +arr[new Random().nextInt(arr.length)];
            }
        }
        for(int i = 0; i < arr1.length; i++){
            if(i == 0)
                ref4 = arr4[0];
            else{
                String[] arr = {arr1[i], arr2[i], arr3[i], arr4[i], arr5[i]};
                ref4 = ref4 + "," +arr[new Random().nextInt(arr.length)];
            }
        }
        for(int i = 0; i < arr1.length; i++){
            if(i == 0)
                ref5 = arr5[0];
            else{
                String[] arr = {arr1[i], arr2[i], arr3[i], arr4[i], arr5[i]};
                ref5 = ref5 + "," +arr[new Random().nextInt(arr.length)];
            }
        }

        File fileX = new File(myDocumentPath+"gaFilter.arff");
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileX, true));
            bw.append("\n" + ref1);
            bw.append("\n" + ref2);
            bw.append("\n" + ref3);
            bw.append("\n" + ref4);
            bw.append("\n" + ref5);
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        mutateData(posArr);
        mutateData(posArr);
        mutateData(posArr);
    }

    public void mutateData(int posArr[]) {
        ref1="";ref2="";ref3="";ref4="";ref5="";

        String[] randData = {
                "0",""+att2[new Random().nextInt(att2.length)], ""+att3[new Random().nextInt(att3.length)],
                ""+att4[new Random().nextInt(att4.length)], ""+randInt(0, 666), ""+randInt(0, 33333),
                ""+att7[new Random().nextInt(att7.length)], ""+att8, ""+att9, ""+att10, ""+att11,
                ""+att12[new Random().nextInt(att12.length)], ""+att13, ""+att14, ""+att15, ""+att16,
                ""+att17, ""+att18, ""+att19, ""+att20, ""+att21[new Random().nextInt(att21.length)],
                ""+att22[new Random().nextInt(att22.length)], ""+att23, ""+att24, ""+randDoub(0.00, 1.00),
                ""+randDoub(0, 1), ""+randDoub(0.00, 1.00), ""+randDoub(0.00, 1.00), ""+randDoub(1.00, 1.50),
                ""+randDoub(0.00, 1.00), ""+randDoub(0.00, 1.00), ""+randInt(1, 99), ""+randInt(100, 255),
                ""+randDoub(1.00, 1.10), ""+att35, ""+randDoub(0.00, 0.10), ""+randDoub(0.00, 0.10), ""+att38,
                ""+att39, ""+att40, ""+att41, ""+att42[new Random().nextInt(att42.length)]};
        for(int i = 0; i < randData.length; i++){
            for(int j : posArr){
                if((i+1) == j){
                    if(!ref1.equals(""))
                        ref1 = ref1 + "," +randData[i];
                    else
                        ref1 = randData[i];
                }
            }
        }
        String[] randData1 = {
                "0",""+att2[new Random().nextInt(att2.length)], ""+att3[new Random().nextInt(att3.length)],
                ""+att4[new Random().nextInt(att4.length)], ""+randInt(0, 666), ""+randInt(0, 33333),
                ""+att7[new Random().nextInt(att7.length)], ""+att8, ""+att9, ""+att10, ""+att11,
                ""+att12[new Random().nextInt(att12.length)], ""+att13, ""+att14, ""+att15, ""+att16,
                ""+att17, ""+att18, ""+att19, ""+att20, ""+att21[new Random().nextInt(att21.length)],
                ""+att22[new Random().nextInt(att22.length)], ""+att23, ""+att24, ""+randDoub(0.00, 1.00),
                ""+randDoub(0, 1), ""+randDoub(0.00, 1.00), ""+randDoub(0.00, 1.00), ""+randDoub(1.00, 1.50),
                ""+randDoub(0.00, 1.00), ""+randDoub(0.00, 1.00), ""+randInt(1, 99), ""+randInt(100, 255),
                ""+randDoub(1.00, 1.10), ""+att35, ""+randDoub(0.00, 0.10), ""+randDoub(0.00, 0.10), ""+att38,
                ""+att39, ""+att40, ""+att41, ""+att42[new Random().nextInt(att42.length)]};
        for(int i = 0; i < randData1.length; i++){
            for(int j : posArr){
                if((i+1) == j){
                    if(!ref2.equals(""))
                        ref2 = ref2 + "," +randData1[i];
                    else
                        ref2 = randData1[i];
                }
            }
        }

        String[] randData2 = {
                "0",""+att2[new Random().nextInt(att2.length)], ""+att3[new Random().nextInt(att3.length)],
                ""+att4[new Random().nextInt(att4.length)], ""+randInt(0, 666), ""+randInt(0, 33333),
                ""+att7[new Random().nextInt(att7.length)], ""+att8, ""+att9, ""+att10, ""+att11,
                ""+att12[new Random().nextInt(att12.length)], ""+att13, ""+att14, ""+att15, ""+att16,
                ""+att17, ""+att18, ""+att19, ""+att20, ""+att21[new Random().nextInt(att21.length)],
                ""+att22[new Random().nextInt(att22.length)], ""+att23, ""+att24, ""+randDoub(0.00, 1.00),
                ""+randDoub(0, 1), ""+randDoub(0.00, 1.00), ""+randDoub(0.00, 1.00), ""+randDoub(1.00, 1.50),
                ""+randDoub(0.00, 1.00), ""+randDoub(0.00, 1.00), ""+randInt(1, 99), ""+randInt(100, 255),
                ""+randDoub(1.00, 1.10), ""+att35, ""+randDoub(0.00, 0.10), ""+randDoub(0.00, 0.10), ""+att38,
                ""+att39, ""+att40, ""+att41, ""+att42[new Random().nextInt(att42.length)]};
        for(int i = 0; i < randData2.length; i++){
            for(int j : posArr){
                if((i+1) == j){
                    if(!ref3.equals(""))
                        ref3 = ref3 + "," +randData2[i];
                    else
                        ref3 = randData2[i];
                }
            }
        }

        String[] randData3 = {
                "0",""+att2[new Random().nextInt(att2.length)], ""+att3[new Random().nextInt(att3.length)],
                ""+att4[new Random().nextInt(att4.length)], ""+randInt(0, 666), ""+randInt(0, 33333),
                ""+att7[new Random().nextInt(att7.length)], ""+att8, ""+att9, ""+att10, ""+att11,
                ""+att12[new Random().nextInt(att12.length)], ""+att13, ""+att14, ""+att15, ""+att16,
                ""+att17, ""+att18, ""+att19, ""+att20, ""+att21[new Random().nextInt(att21.length)],
                ""+att22[new Random().nextInt(att22.length)], ""+att23, ""+att24, ""+randDoub(0.00, 1.00),
                ""+randDoub(0, 1), ""+randDoub(0.00, 1.00), ""+randDoub(0.00, 1.00), ""+randDoub(1.00, 1.50),
                ""+randDoub(0.00, 1.00), ""+randDoub(0.00, 1.00), ""+randInt(1, 99), ""+randInt(100, 255),
                ""+randDoub(1.00, 1.10), ""+att35, ""+randDoub(0.00, 0.10), ""+randDoub(0.00, 0.10), ""+att38,
                ""+att39, ""+att40, ""+att41, ""+att42[new Random().nextInt(att42.length)]};
        for(int i = 0; i < randData3.length; i++){
            for(int j : posArr){
                if((i+1) == j){
                    if(!ref4.equals(""))
                        ref4 = ref4 + "," +randData3[i];
                    else
                        ref4 = randData3[i];
                }
            }
        }

        String[] randData4 = {
                "0",""+att2[new Random().nextInt(att2.length)], ""+att3[new Random().nextInt(att3.length)],
                ""+att4[new Random().nextInt(att4.length)], ""+randInt(0, 666), ""+randInt(0, 33333),
                ""+att7[new Random().nextInt(att7.length)], ""+att8, ""+att9, ""+att10, ""+att11,
                ""+att12[new Random().nextInt(att12.length)], ""+att13, ""+att14, ""+att15, ""+att16,
                ""+att17, ""+att18, ""+att19, ""+att20, ""+att21[new Random().nextInt(att21.length)],
                ""+att22[new Random().nextInt(att22.length)], ""+att23, ""+att24, ""+randDoub(0.00, 1.00),
                ""+randDoub(0, 1), ""+randDoub(0.00, 1.00), ""+randDoub(0.00, 1.00), ""+randDoub(1.00, 1.50),
                ""+randDoub(0.00, 1.00), ""+randDoub(0.00, 1.00), ""+randInt(1, 99), ""+randInt(100, 255),
                ""+randDoub(1.00, 1.10), ""+att35, ""+randDoub(0.00, 0.10), ""+randDoub(0.00, 0.10), ""+att38,
                ""+att39, ""+att40, ""+att41, ""+att42[new Random().nextInt(att42.length)]};
        for(int i = 0; i < randData4.length; i++){
            for(int j : posArr){
                if((i+1) == j){
                    if(!ref5.equals(""))
                        ref5 = ref5 + "," +randData4[i];
                    else
                        ref5 = randData4[i];
                }
            }
        }
        File fileX = new File(myDocumentPath+"gaFilter.arff");
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileX, true));
            bw.append("\n" + ref1);
            bw.append("\n" + ref2);
            bw.append("\n" + ref3);
            bw.append("\n" + ref4);
            bw.append("\n" + ref5);
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void acceptData() {
        File file = new File(myDocumentPath+"kddminiX.arff");
        File fileX = new File(myDocumentPath+"GA-acted.arff");
        if(fileX.exists() && !fileX.isDirectory()) {
            // Delete file to recreate
            fileX.delete();
        }
        fileX = new File(myDocumentPath+"GA-acted.arff");
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileX));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("@relation")) {
                    if(!line.trim().equals("")) {
                        bw.append("\n"+line);
                    }
                    continue;
                }else if (line.startsWith("@attribute")) {
                    if(!line.trim().equals("")) {
                        bw.append("\n"+line);
                    }
                    continue;
                } else if (line.startsWith("@data")) {
                    if(!line.trim().equals("")) {
                        bw.append("\n"+line);
                    }
                    break;
                }
            }
            bw.append("\n");
            bw.close();
            br.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        File file1 = new File(myDocumentPath+"gaFilter.arff");
        File fileX1 = new File(myDocumentPath+"GA-acted.arff");
        try {
            BufferedReader br = new BufferedReader(new FileReader(file1));
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileX1, true));
            String line;
            while((line = br.readLine()) != null){
                bw.append("\n"+line);
            }
            bw.close();
            br.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public int randLine(int num){
        if(rowTrack.length == 0){
            int old = rowTrack.length;
            rowTrack = Arrays.copyOf(rowTrack, old+1);
            rowTrack[old] = randInt(1, num);
            num = rowTrack[old];
        }else{
            int numX = randInt(1, num);
            for(int i = 0; i < rowTrack.length; i++){
                if(numX == rowTrack[i]){
                    randLine(num);
                    break;
                }else
                    continue;
            }
            int old = rowTrack.length;
            rowTrack = Arrays.copyOf(rowTrack, old+1);
            rowTrack[old] = numX;
            num = numX;
        }
        return num;
    }

    public String readSpecLine(int line, String textFile) {
        FileReader tempFileReader = null;
        BufferedReader tempBufferedReader = null;
        try {
            tempFileReader = new FileReader(textFile);
            tempBufferedReader = new BufferedReader(tempFileReader);
        } catch (Exception e) {}
        String returnStr = "ERROR";
        for (int i = 0; i < line - 1; i++) {
            try {
                tempBufferedReader.readLine();
            } catch (Exception e) {}
        }
        try {
            returnStr = tempBufferedReader.readLine();
        } catch (Exception e) {}

        return returnStr;
    }

    public static int randInt(int min, int max) {
        Random rand = new Random();
        int randomNum = rand.nextInt((max - min) + 1) + min;
        
        return randomNum;
    }

    public static String randDoub(double min, double max) {
        double random = new Random().nextDouble();
        double result = min + (random * (max - min));
        DecimalFormat f = new DecimalFormat("##.00");
        return f.format(result);
    }
    
    int att1 = 0;
    String att2[] =  {"tcp","udp","icmp"};
    String att3[] = {"vmnet","smtp","ntp_u","shell","kshell","aol","imap4","urh_i","netbios_ssn","tftp_u",
        "mtp","uucp","nnsp","echo","tim_i","ssh","iso_tsap","time","netbios_ns","systat","hostnames","login","efs",
        "supdup","http_8001","courier","ctf","finger","nntp","ftp_data","red_i","ldap","http","ftp","pm_dump","exec",
        "klogin","auth","netbios_dgm","other","link","X11","discard","private","remote_job","IRC","daytime",
        "pop_3","pop_2","gopher","sunrpc","name","rje","domain","uucp_path","http_2784","Z39_50","domain_u",
        "csnet_ns","whois","eco_i","bgp","sql_net","printer","telnet","ecr_i","urp_i","netstat","http_443","harvest"};
    String att4[] = {"RSTR","S3","SF","RSTO","SH","OTH","S2","RSTOS0","S1","S0","REJ"};
    int att5 = 0;
    int att6 = 0;
    int att7[] = {1,0};
    int att8 = 0;
    int att9 = 0;
    int att10 = 0;
    int att11 = 0;
    int att12[] = {1,0};
    int att13 = 0;
    int att14 = 0;
    int att15 = 0;
    int att16 = 0;
    int att17 = 0;
    int att18 = 0;
    int att19 = 0;
    int att20 = 0;
    int att21[] = {1,0};
    int att22[] = {1,0};
    int att23 = 0;
    int att24 = 0;
    double att25 = 0;
    double att26 = 0;
    double att27 = 0;
    double att28 = 0;
    double att29 = 1.00;
    double att30 = 0;
    double att31 = 0;
    int att32 = 0;
    int att33 = 0;
    double att34 = 1.00;
    double att35 = 0;
    double att36 = 0;
    double att37 = 0;
    double att38 = 0;
    double att39 = 0;
    double att40 = 0;
    double att41 = 0;
    String att42[] = {"back","teardrop","loadmodule","neptune","rootkit","phf","satan","buffer_overflow","ftp_write",
        "land","spy","ipsweep","multihop","smurf","pod","perl","warezclient","nmap","imap","warezmaster","portsweep",
        "normal","guess_passwd"};
}



//        ref = "0,"+att2[new Random().nextInt(att2.length)]+","+att3[new Random().nextInt(att3.length)]+","
//                +att4[new Random().nextInt(att4.length)]+","+randInt(0, 666)+","+randInt(0, 33333)+","+
//                att7[new Random().nextInt(att7.length)]+","+att8+","+att9+","+att10+","+att11+","+
//                att12[new Random().nextInt(att12.length)]+","+att13+","+att14+","+att15+","+att16+","
//                +att17+","+att18+","+att19+","+att20+","+att21[new Random().nextInt(att21.length)]+","+
//                att22[new Random().nextInt(att22.length)]+","+att23+","+att24+","+randDoub(0.00, 0.00)+","
//                +randDoub(0, 1)+","+randDoub(0.00, 0.00)+","+randDoub(0.00, 0.00)+","+randDoub(1.00, 1.50)+","
//                +randDoub(0.00, 0.00)+","+randDoub(0.00, 0.00)+","+randInt(1, 99)+","+randInt(100, 255)+","
//                +randDoub(1.00, 1.10)+","+att35+","+randDoub(0.00, 0.10)+","+randDoub(0.00, 0.10)+","+att38+","
//                +att39+","+att40+","+att41+","+att42[new Random().nextInt(att42.length)];
//        ref1 = data1[0]+","+att2[new Random().nextInt(att2.length)]+","+att3[new Random().nextInt(att3.length)]+","
//                +att4[new Random().nextInt(att4.length)]+","+randInt(0, 666)+","+randInt(0, 33333)+","+
//                att7[new Random().nextInt(att7.length)]+","+att8+","+att9+","+att10+","+att11+","+
//                att12[new Random().nextInt(att12.length)]+","+att13+","+att14+","+att15+","+att16+","
//                +att17+","+att18+","+att19+","+att20+","+att21[new Random().nextInt(att21.length)]+","+
//                att22[new Random().nextInt(att22.length)]+","+att23+","+att24+","+randDoub(0.00, 0.00)+","
//                +randDoub(0, 1)+","+randDoub(0.00, 0.00)+","+randDoub(0.00, 0.00)+","+randDoub(1.00, 1.50)+","
//                +randDoub(0.00, 0.00)+","+randDoub(0.00, 0.00)+","+randInt(1, 99)+","+randInt(100, 255)+","
//                +randDoub(1.00, 1.10)+","+att35+","+randDoub(0.00, 0.10)+","+randDoub(0.00, 0.10)+","+att38+","
//                +att39+","+att40+","+att41+","+data1[41];
//        ref2 = data2[0]+","+att2[new Random().nextInt(att2.length)]+","+att3[new Random().nextInt(att3.length)]+","
//                +att4[new Random().nextInt(att4.length)]+","+randInt(0, 666)+","+randInt(0, 33333)+","+
//                att7[new Random().nextInt(att7.length)]+","+att8+","+att9+","+att10+","+att11+","+
//                att12[new Random().nextInt(att12.length)]+","+att13+","+att14+","+att15+","+att16+","
//                +att17+","+att18+","+att19+","+att20+","+att21[new Random().nextInt(att21.length)]+","+
//                att22[new Random().nextInt(att22.length)]+","+att23+","+att24+","+randDoub(0.00, 0.00)+","
//                +randDoub(0, 1)+","+randDoub(0.00, 0.00)+","+randDoub(0.00, 0.00)+","+randDoub(1.00, 1.50)+","
//                +randDoub(0.00, 0.00)+","+randDoub(0.00, 0.00)+","+randInt(1, 99)+","+randInt(100, 255)+","
//                +randDoub(1.00, 1.10)+","+att35+","+randDoub(0.00, 0.10)+","+randDoub(0.00, 0.10)+","+att38+","
//                +att39+","+att40+","+att41+","+data2[41];