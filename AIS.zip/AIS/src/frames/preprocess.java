/*
 * preprocess.java
 * Creates a frame to preprocess
 *
 * Created on 24-Dec-2016, 19:46:41
 */

package frames;

import java.awt.Image;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Arrays;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import org.apache.commons.lang3.ArrayUtils;

/**
 *
 * @author DeGod
 */
public class preprocess extends javax.swing.JFrame {

    String myDocumentPath = System.getProperty("user.home") + "\\Documents\\AIS\\";
    String attrNames[] = {"duration", "protocol_type", "label"};
    int attrCount = 3;
    int[] posArr = {1, 2, 42};

    public preprocess() {
        initComponents();
        setTitle("AIS - Attribute Selection Preprocessor");
        setLocationRelativeTo(null);
        setResizable(false);
        setIconImage(new ImageIcon("src/imgs/aisFav.png").getImage());
        jLabel1.setIcon(new ImageIcon(new ImageIcon("src/imgs/loaderWheel.gif").getImage().getScaledInstance(40,40,
                Image.SCALE_DEFAULT)));
        jLabel1.setText("Attribute Selection Preprocessor");
        next.setIcon(new ImageIcon(new ImageIcon("src/imgs/classify.png").getImage().getScaledInstance(30,30,
                Image.SCALE_DEFAULT)));
        next.setText("Let's Classify");
        attr1.setSelected(true);
        attr2.setSelected(true);
        attr42.setSelected(true);
        initReadIt();
        status.setText("Attributes Selected: "+attrCount);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        backBtn = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        attr1 = new javax.swing.JCheckBox();
        attr2 = new javax.swing.JCheckBox();
        attr3 = new javax.swing.JCheckBox();
        attr4 = new javax.swing.JCheckBox();
        attr8 = new javax.swing.JCheckBox();
        attr7 = new javax.swing.JCheckBox();
        attr6 = new javax.swing.JCheckBox();
        attr5 = new javax.swing.JCheckBox();
        attr12 = new javax.swing.JCheckBox();
        attr11 = new javax.swing.JCheckBox();
        attr10 = new javax.swing.JCheckBox();
        attr9 = new javax.swing.JCheckBox();
        attr25 = new javax.swing.JCheckBox();
        attr24 = new javax.swing.JCheckBox();
        attr23 = new javax.swing.JCheckBox();
        attr26 = new javax.swing.JCheckBox();
        attr15 = new javax.swing.JCheckBox();
        attr16 = new javax.swing.JCheckBox();
        attr17 = new javax.swing.JCheckBox();
        attr18 = new javax.swing.JCheckBox();
        attr19 = new javax.swing.JCheckBox();
        attr20 = new javax.swing.JCheckBox();
        attr21 = new javax.swing.JCheckBox();
        attr22 = new javax.swing.JCheckBox();
        attr39 = new javax.swing.JCheckBox();
        attr38 = new javax.swing.JCheckBox();
        attr37 = new javax.swing.JCheckBox();
        attr40 = new javax.swing.JCheckBox();
        attr29 = new javax.swing.JCheckBox();
        attr30 = new javax.swing.JCheckBox();
        attr31 = new javax.swing.JCheckBox();
        attr32 = new javax.swing.JCheckBox();
        attr33 = new javax.swing.JCheckBox();
        attr34 = new javax.swing.JCheckBox();
        attr35 = new javax.swing.JCheckBox();
        attr36 = new javax.swing.JCheckBox();
        attr13 = new javax.swing.JCheckBox();
        attr14 = new javax.swing.JCheckBox();
        attr27 = new javax.swing.JCheckBox();
        attr28 = new javax.swing.JCheckBox();
        attr41 = new javax.swing.JCheckBox();
        attr42 = new javax.swing.JCheckBox();
        status = new javax.swing.JLabel();
        takeAll = new javax.swing.JCheckBox();
        remAll = new javax.swing.JCheckBox();
        status1 = new javax.swing.JLabel();
        next = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(40, 42, 43));

        jLabel1.setFont(new java.awt.Font("Nirmala UI", 1, 24));
        jLabel1.setForeground(new java.awt.Color(255, 255, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Upload an Attribute Relation file");

        backBtn.setFont(new java.awt.Font("Tahoma", 1, 24));
        backBtn.setForeground(new java.awt.Color(255, 255, 255));
        backBtn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        backBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/back.png"))); // NOI18N
        backBtn.setText("Back");
        backBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        backBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backBtnMouseClicked(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(102, 102, 0));

        attr1.setBackground(new java.awt.Color(102, 102, 0));
        attr1.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr1.setForeground(new java.awt.Color(255, 255, 255));
        attr1.setText("duration");
        attr1.setEnabled(false);
        attr1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr1ActionPerformed(evt);
            }
        });

        attr2.setBackground(new java.awt.Color(102, 102, 0));
        attr2.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr2.setForeground(new java.awt.Color(255, 255, 255));
        attr2.setText("protocol_type");
        attr2.setEnabled(false);
        attr2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr2ActionPerformed(evt);
            }
        });

        attr3.setBackground(new java.awt.Color(102, 102, 0));
        attr3.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr3.setForeground(new java.awt.Color(255, 255, 255));
        attr3.setText("service");
        attr3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr3ActionPerformed(evt);
            }
        });

        attr4.setBackground(new java.awt.Color(102, 102, 0));
        attr4.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr4.setForeground(new java.awt.Color(255, 255, 255));
        attr4.setText("flag");
        attr4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr4ActionPerformed(evt);
            }
        });

        attr8.setBackground(new java.awt.Color(102, 102, 0));
        attr8.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr8.setForeground(new java.awt.Color(255, 255, 255));
        attr8.setText("wrong_fragment");
        attr8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr8ActionPerformed(evt);
            }
        });

        attr7.setBackground(new java.awt.Color(102, 102, 0));
        attr7.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr7.setForeground(new java.awt.Color(255, 255, 255));
        attr7.setText("land");
        attr7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr7ActionPerformed(evt);
            }
        });

        attr6.setBackground(new java.awt.Color(102, 102, 0));
        attr6.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr6.setForeground(new java.awt.Color(255, 255, 255));
        attr6.setText("dst_bytes");
        attr6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr6ActionPerformed(evt);
            }
        });

        attr5.setBackground(new java.awt.Color(102, 102, 0));
        attr5.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr5.setForeground(new java.awt.Color(255, 255, 255));
        attr5.setText("src_bytes");
        attr5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr5ActionPerformed(evt);
            }
        });

        attr12.setBackground(new java.awt.Color(102, 102, 0));
        attr12.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr12.setForeground(new java.awt.Color(255, 255, 255));
        attr12.setText("logged_in");
        attr12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr12ActionPerformed(evt);
            }
        });

        attr11.setBackground(new java.awt.Color(102, 102, 0));
        attr11.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr11.setForeground(new java.awt.Color(255, 255, 255));
        attr11.setText("num_failed_logins");
        attr11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr11ActionPerformed(evt);
            }
        });

        attr10.setBackground(new java.awt.Color(102, 102, 0));
        attr10.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr10.setForeground(new java.awt.Color(255, 255, 255));
        attr10.setText("hot");
        attr10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr10ActionPerformed(evt);
            }
        });

        attr9.setBackground(new java.awt.Color(102, 102, 0));
        attr9.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr9.setForeground(new java.awt.Color(255, 255, 255));
        attr9.setText("urgent");
        attr9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr9ActionPerformed(evt);
            }
        });

        attr25.setBackground(new java.awt.Color(102, 102, 0));
        attr25.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr25.setForeground(new java.awt.Color(255, 255, 255));
        attr25.setText("serror_rate");
        attr25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr25ActionPerformed(evt);
            }
        });

        attr24.setBackground(new java.awt.Color(102, 102, 0));
        attr24.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr24.setForeground(new java.awt.Color(255, 255, 255));
        attr24.setText("srv_count");
        attr24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr24ActionPerformed(evt);
            }
        });

        attr23.setBackground(new java.awt.Color(102, 102, 0));
        attr23.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr23.setForeground(new java.awt.Color(255, 255, 255));
        attr23.setText("count");
        attr23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr23ActionPerformed(evt);
            }
        });

        attr26.setBackground(new java.awt.Color(102, 102, 0));
        attr26.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr26.setForeground(new java.awt.Color(255, 255, 255));
        attr26.setText("srv_serror_rate");
        attr26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr26ActionPerformed(evt);
            }
        });

        attr15.setBackground(new java.awt.Color(102, 102, 0));
        attr15.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr15.setForeground(new java.awt.Color(255, 255, 255));
        attr15.setText("lsu_attempted");
        attr15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr15ActionPerformed(evt);
            }
        });

        attr16.setBackground(new java.awt.Color(102, 102, 0));
        attr16.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr16.setForeground(new java.awt.Color(255, 255, 255));
        attr16.setText("lnum_root");
        attr16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr16ActionPerformed(evt);
            }
        });

        attr17.setBackground(new java.awt.Color(102, 102, 0));
        attr17.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr17.setForeground(new java.awt.Color(255, 255, 255));
        attr17.setText("lnum_file_creations");
        attr17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr17ActionPerformed(evt);
            }
        });

        attr18.setBackground(new java.awt.Color(102, 102, 0));
        attr18.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr18.setForeground(new java.awt.Color(255, 255, 255));
        attr18.setText("lnum_shells");
        attr18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr18ActionPerformed(evt);
            }
        });

        attr19.setBackground(new java.awt.Color(102, 102, 0));
        attr19.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr19.setForeground(new java.awt.Color(255, 255, 255));
        attr19.setText("lnum_access_files");
        attr19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr19ActionPerformed(evt);
            }
        });

        attr20.setBackground(new java.awt.Color(102, 102, 0));
        attr20.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr20.setForeground(new java.awt.Color(255, 255, 255));
        attr20.setText("lnum_outbound_cmds");
        attr20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr20ActionPerformed(evt);
            }
        });

        attr21.setBackground(new java.awt.Color(102, 102, 0));
        attr21.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr21.setForeground(new java.awt.Color(255, 255, 255));
        attr21.setText("is_host_login");
        attr21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr21ActionPerformed(evt);
            }
        });

        attr22.setBackground(new java.awt.Color(102, 102, 0));
        attr22.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr22.setForeground(new java.awt.Color(255, 255, 255));
        attr22.setText("is_guest_login");
        attr22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr22ActionPerformed(evt);
            }
        });

        attr39.setBackground(new java.awt.Color(102, 102, 0));
        attr39.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr39.setForeground(new java.awt.Color(255, 255, 255));
        attr39.setText("dst_host_srv_serror_rate");
        attr39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr39ActionPerformed(evt);
            }
        });

        attr38.setBackground(new java.awt.Color(102, 102, 0));
        attr38.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr38.setForeground(new java.awt.Color(255, 255, 255));
        attr38.setText("dst_host_serror_rate");
        attr38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr38ActionPerformed(evt);
            }
        });

        attr37.setBackground(new java.awt.Color(102, 102, 0));
        attr37.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr37.setForeground(new java.awt.Color(255, 255, 255));
        attr37.setText("dst_host_srv_diff_host_rate");
        attr37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr37ActionPerformed(evt);
            }
        });

        attr40.setBackground(new java.awt.Color(102, 102, 0));
        attr40.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr40.setForeground(new java.awt.Color(255, 255, 255));
        attr40.setText("dst_host_rerror_rate");
        attr40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr40ActionPerformed(evt);
            }
        });

        attr29.setBackground(new java.awt.Color(102, 102, 0));
        attr29.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr29.setForeground(new java.awt.Color(255, 255, 255));
        attr29.setText("same_srv_rate");
        attr29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr29ActionPerformed(evt);
            }
        });

        attr30.setBackground(new java.awt.Color(102, 102, 0));
        attr30.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr30.setForeground(new java.awt.Color(255, 255, 255));
        attr30.setText("diff_srv_rate");
        attr30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr30ActionPerformed(evt);
            }
        });

        attr31.setBackground(new java.awt.Color(102, 102, 0));
        attr31.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr31.setForeground(new java.awt.Color(255, 255, 255));
        attr31.setText("srv_diff_host_rate");
        attr31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr31ActionPerformed(evt);
            }
        });

        attr32.setBackground(new java.awt.Color(102, 102, 0));
        attr32.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr32.setForeground(new java.awt.Color(255, 255, 255));
        attr32.setText("dst_host_count");
        attr32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr32ActionPerformed(evt);
            }
        });

        attr33.setBackground(new java.awt.Color(102, 102, 0));
        attr33.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr33.setForeground(new java.awt.Color(255, 255, 255));
        attr33.setText("dst_host_srv_count");
        attr33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr33ActionPerformed(evt);
            }
        });

        attr34.setBackground(new java.awt.Color(102, 102, 0));
        attr34.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr34.setForeground(new java.awt.Color(255, 255, 255));
        attr34.setText("dst_host_same_srv_rate");
        attr34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr34ActionPerformed(evt);
            }
        });

        attr35.setBackground(new java.awt.Color(102, 102, 0));
        attr35.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr35.setForeground(new java.awt.Color(255, 255, 255));
        attr35.setText("dst_host_diff_srv_rate");
        attr35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr35ActionPerformed(evt);
            }
        });

        attr36.setBackground(new java.awt.Color(102, 102, 0));
        attr36.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr36.setForeground(new java.awt.Color(255, 255, 255));
        attr36.setText("dst_host_same_src_port_rate");
        attr36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr36ActionPerformed(evt);
            }
        });

        attr13.setBackground(new java.awt.Color(102, 102, 0));
        attr13.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr13.setForeground(new java.awt.Color(255, 255, 255));
        attr13.setText("lnum_compromised");
        attr13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr13ActionPerformed(evt);
            }
        });

        attr14.setBackground(new java.awt.Color(102, 102, 0));
        attr14.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr14.setForeground(new java.awt.Color(255, 255, 255));
        attr14.setText("lroot_shell");
        attr14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr14ActionPerformed(evt);
            }
        });

        attr27.setBackground(new java.awt.Color(102, 102, 0));
        attr27.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr27.setForeground(new java.awt.Color(255, 255, 255));
        attr27.setText("rerror_rate");
        attr27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr27ActionPerformed(evt);
            }
        });

        attr28.setBackground(new java.awt.Color(102, 102, 0));
        attr28.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr28.setForeground(new java.awt.Color(255, 255, 255));
        attr28.setText("srv_rerror_rate");
        attr28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr28ActionPerformed(evt);
            }
        });

        attr41.setBackground(new java.awt.Color(102, 102, 0));
        attr41.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr41.setForeground(new java.awt.Color(255, 255, 255));
        attr41.setText("dst_host_srv_rerror_rate");
        attr41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr41ActionPerformed(evt);
            }
        });

        attr42.setBackground(new java.awt.Color(102, 102, 0));
        attr42.setFont(new java.awt.Font("Tahoma", 1, 11));
        attr42.setForeground(new java.awt.Color(255, 255, 255));
        attr42.setText("label");
        attr42.setEnabled(false);
        attr42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attr42ActionPerformed(evt);
            }
        });

        status.setFont(new java.awt.Font("Tahoma", 1, 12));
        status.setForeground(new java.awt.Color(255, 204, 204));
        status.setText("jLabel2");

        takeAll.setBackground(new java.awt.Color(102, 102, 0));
        takeAll.setFont(new java.awt.Font("Tahoma", 1, 12));
        takeAll.setForeground(new java.awt.Color(255, 255, 255));
        takeAll.setText("Select All");
        takeAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                takeAllActionPerformed(evt);
            }
        });

        remAll.setBackground(new java.awt.Color(102, 102, 0));
        remAll.setFont(new java.awt.Font("Tahoma", 1, 12));
        remAll.setForeground(new java.awt.Color(255, 255, 255));
        remAll.setText("Deselect All");
        remAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                remAllActionPerformed(evt);
            }
        });

        status1.setFont(new java.awt.Font("Tahoma", 1, 12));
        status1.setForeground(new java.awt.Color(255, 204, 204));
        status1.setText("jLabel2");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(status1, javax.swing.GroupLayout.DEFAULT_SIZE, 449, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(attr14, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(attr28, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(attr13, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(attr27, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(attr1, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(attr2, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(attr3, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(attr4, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(attr5, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(attr6, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(attr7, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(attr8, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(attr9, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(attr10, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(attr11, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(attr12, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(attr26, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                                    .addComponent(attr25, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                                    .addComponent(attr24, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                                    .addComponent(attr23, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                                    .addComponent(attr22, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                                    .addComponent(attr21, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                                    .addComponent(attr20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(attr19, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                                    .addComponent(attr18, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                                    .addComponent(attr17, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                                    .addComponent(attr16, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                                    .addComponent(attr15, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE))))
                        .addGap(2, 2, 2)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(attr29, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(attr30, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(attr31, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(attr32, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(attr33, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(attr34, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(attr35, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(attr36, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(attr37, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(attr38, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(attr39, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(attr40, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(attr41, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(attr42, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addComponent(status, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(takeAll)
                        .addGap(18, 18, 18)
                        .addComponent(remAll)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(attr15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr22)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr23)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr24)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr26))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(attr29)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr30)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr31)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr32)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr33)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr34)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr35)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr36)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr37)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr38)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr39)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr40))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(attr1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(attr12)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(attr13)
                    .addComponent(attr27)
                    .addComponent(attr41))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(attr14)
                    .addComponent(attr28)
                    .addComponent(attr42))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(remAll)
                        .addGap(9, 9, 9))
                    .addComponent(status, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(takeAll)
                        .addGap(3, 3, 3)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(status1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        next.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        next.setForeground(new java.awt.Color(255, 255, 255));
        next.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        next.setText("Let's Classify");
        next.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        next.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nextMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 469, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(backBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 120, Short.MAX_VALUE)
                        .addComponent(next, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(backBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(next, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backBtnMouseClicked
        // Takes user back to the upload .arff file
        uploadFile up = new uploadFile();
        up.setVisible(true);
        dispose();
}//GEN-LAST:event_backBtnMouseClicked

    private void attr1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr1ActionPerformed
        // TODO add your handling code here:
        fetchAttr("duration", attr1, 1);
    }//GEN-LAST:event_attr1ActionPerformed

    private void attr2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr2ActionPerformed
        // TODO add your handling code here:
        fetchAttr("protocol_type", attr2, 2);
    }//GEN-LAST:event_attr2ActionPerformed

    private void attr3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr3ActionPerformed
        // TODO add your handling code here:
        fetchAttr("service", attr3, 3);
    }//GEN-LAST:event_attr3ActionPerformed

    private void attr4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr4ActionPerformed
        // TODO add your handling code here:
        fetchAttr("flag", attr4, 4);
    }//GEN-LAST:event_attr4ActionPerformed

    private void attr5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr5ActionPerformed
        // TODO add your handling code here:
        fetchAttr("src_bytes", attr5, 5);
    }//GEN-LAST:event_attr5ActionPerformed

    private void attr6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr6ActionPerformed
        // TODO add your handling code here:
        fetchAttr("dst_bytes", attr6, 6);
    }//GEN-LAST:event_attr6ActionPerformed

    private void attr7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr7ActionPerformed
        // TODO add your handling code here:
        fetchAttr("land", attr7, 7);
    }//GEN-LAST:event_attr7ActionPerformed

    private void attr8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr8ActionPerformed
        // TODO add your handling code here:
        fetchAttr("wrong_fragment", attr8, 8);
    }//GEN-LAST:event_attr8ActionPerformed

    private void attr9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr9ActionPerformed
        // TODO add your handling code here:
        fetchAttr("urgent", attr9, 9);
    }//GEN-LAST:event_attr9ActionPerformed

    private void attr10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr10ActionPerformed
        // TODO add your handling code here:
        fetchAttr("hot", attr10, 10);
    }//GEN-LAST:event_attr10ActionPerformed

    private void attr11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr11ActionPerformed
        // TODO add your handling code here:
        fetchAttr("num_failed_logins", attr11, 11);
    }//GEN-LAST:event_attr11ActionPerformed

    private void attr12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr12ActionPerformed
        // TODO add your handling code here:
        fetchAttr("logged_in", attr12, 12);
    }//GEN-LAST:event_attr12ActionPerformed

    private void attr13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr13ActionPerformed
        // TODO add your handling code here:
        fetchAttr("lnum_compromised", attr13, 13);
    }//GEN-LAST:event_attr13ActionPerformed

    private void attr14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr14ActionPerformed
        // TODO add your handling code here:
        fetchAttr("lroot_shell", attr14, 14);
    }//GEN-LAST:event_attr14ActionPerformed

    private void attr15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr15ActionPerformed
        // TODO add your handling code here:
        fetchAttr("lsu_attempted", attr15, 15);
    }//GEN-LAST:event_attr15ActionPerformed

    private void attr16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr16ActionPerformed
        // TODO add your handling code here:
        fetchAttr("lnum_root", attr16, 16);
    }//GEN-LAST:event_attr16ActionPerformed

    private void attr17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr17ActionPerformed
        // TODO add your handling code here:
        fetchAttr("lnum_file_creations", attr17, 17);
    }//GEN-LAST:event_attr17ActionPerformed

    private void attr18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr18ActionPerformed
        // TODO add your handling code here:
        fetchAttr("lnum_shells", attr18, 18);
    }//GEN-LAST:event_attr18ActionPerformed

    private void attr19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr19ActionPerformed
        // TODO add your handling code here:
        fetchAttr("lnum_access_files", attr19, 19);
    }//GEN-LAST:event_attr19ActionPerformed

    private void attr20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr20ActionPerformed
        // TODO add your handling code here:
        fetchAttr("lnum_outbound_cmds", attr20, 20);
    }//GEN-LAST:event_attr20ActionPerformed

    private void attr21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr21ActionPerformed
        // TODO add your handling code here:
        fetchAttr("is_host_login", attr21, 21);
    }//GEN-LAST:event_attr21ActionPerformed

    private void attr22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr22ActionPerformed
        // TODO add your handling code here:
        fetchAttr("is_guest_login", attr22, 22);
    }//GEN-LAST:event_attr22ActionPerformed

    private void attr23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr23ActionPerformed
        // TODO add your handling code here:
        fetchAttr("count", attr23, 23);
    }//GEN-LAST:event_attr23ActionPerformed

    private void attr24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr24ActionPerformed
        // TODO add your handling code here:
        fetchAttr("srv_count", attr24, 24);
    }//GEN-LAST:event_attr24ActionPerformed

    private void attr25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr25ActionPerformed
        // TODO add your handling code here:
        fetchAttr("serror_rate", attr25, 25);
    }//GEN-LAST:event_attr25ActionPerformed

    private void attr26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr26ActionPerformed
        // TODO add your handling code here:
        fetchAttr("srv_serror_rate", attr26, 26);
    }//GEN-LAST:event_attr26ActionPerformed

    private void attr27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr27ActionPerformed
        // TODO add your handling code here:
        fetchAttr("rerror_rate", attr27, 27);
    }//GEN-LAST:event_attr27ActionPerformed

    private void attr28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr28ActionPerformed
        // TODO add your handling code here:
        fetchAttr("srv_rerror_rate", attr28, 28);
    }//GEN-LAST:event_attr28ActionPerformed

    private void attr29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr29ActionPerformed
        // TODO add your handling code here:
        fetchAttr("same_srv_rate", attr29, 29);
    }//GEN-LAST:event_attr29ActionPerformed

    private void attr30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr30ActionPerformed
        // TODO add your handling code here:
        fetchAttr("diff_srv_rate", attr30, 30);
    }//GEN-LAST:event_attr30ActionPerformed

    private void attr31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr31ActionPerformed
        // TODO add your handling code here:
        fetchAttr("srv_diff_host_rate", attr31, 31);
    }//GEN-LAST:event_attr31ActionPerformed

    private void attr32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr32ActionPerformed
        // TODO add your handling code here:
        fetchAttr("dst_host_count", attr32, 32);
    }//GEN-LAST:event_attr32ActionPerformed

    private void attr33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr33ActionPerformed
        // TODO add your handling code here:
        fetchAttr("dst_host_srv_count", attr33, 33);
    }//GEN-LAST:event_attr33ActionPerformed

    private void attr34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr34ActionPerformed
        // TODO add your handling code here:
        fetchAttr("dst_host_same_srv_rate", attr34, 34);
    }//GEN-LAST:event_attr34ActionPerformed

    private void attr35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr35ActionPerformed
        // TODO add your handling code here:
        fetchAttr("dst_host_diff_srv_rate", attr35, 35);
    }//GEN-LAST:event_attr35ActionPerformed

    private void attr36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr36ActionPerformed
        // TODO add your handling code here:
        fetchAttr("dst_host_same_src_port_rate", attr36, 36);
    }//GEN-LAST:event_attr36ActionPerformed

    private void attr37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr37ActionPerformed
        // TODO add your handling code here:
        fetchAttr("dst_host_srv_diff_host_rate", attr37, 37);
    }//GEN-LAST:event_attr37ActionPerformed

    private void attr38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr38ActionPerformed
        // TODO add your handling code here:
        fetchAttr("dst_host_serror_rate", attr38, 38);
    }//GEN-LAST:event_attr38ActionPerformed

    private void attr39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr39ActionPerformed
        // TODO add your handling code here:
        fetchAttr("dst_host_srv_serror_rate", attr39, 39);
    }//GEN-LAST:event_attr39ActionPerformed

    private void attr40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr40ActionPerformed
        // TODO add your handling code here:
        fetchAttr("dst_host_rerror_rate", attr40, 40);
    }//GEN-LAST:event_attr40ActionPerformed

    private void attr41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr41ActionPerformed
        // TODO add your handling code here:
        fetchAttr("dst_host_srv_rerror_rate", attr41, 41);
    }//GEN-LAST:event_attr41ActionPerformed

    private void attr42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attr42ActionPerformed
        // TODO add your handling code here:
        fetchAttr("label", attr42, 42);
    }//GEN-LAST:event_attr42ActionPerformed

    private void nextMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nextMouseClicked
        // TODO add your handling code here:
        readIt();
        dashBoard db = new dashBoard();
        db.setVisible(true);
        db.posArr = posArr;
        dispose();
    }//GEN-LAST:event_nextMouseClicked

    private void remAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_remAllActionPerformed
        // TODO add your handling code here:
        triggerCheckBox(false);
        remAll.setSelected(true);
    }//GEN-LAST:event_remAllActionPerformed

    private void takeAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_takeAllActionPerformed
        // TODO add your handling code here:
        triggerCheckBox(true);
        takeAll.setSelected(true);
    }//GEN-LAST:event_takeAllActionPerformed

    public void triggerCheckBox(boolean btn){
        if(btn == true){
            attrCount = 3;
        }
        attr3.setSelected(btn);
        attr4.setSelected(btn);
        attr5.setSelected(btn);
        attr6.setSelected(btn);
        attr7.setSelected(btn);
        attr8.setSelected(btn);
        attr9.setSelected(btn);
        attr10.setSelected(btn);
        attr11.setSelected(btn);
        attr12.setSelected(btn);
        attr13.setSelected(btn);
        attr14.setSelected(btn);
        attr15.setSelected(btn);
        attr16.setSelected(btn);
        attr17.setSelected(btn);
        attr18.setSelected(btn);
        attr19.setSelected(btn);
        attr20.setSelected(btn);
        attr21.setSelected(btn);
        attr22.setSelected(btn);
        attr23.setSelected(btn);
        attr24.setSelected(btn);
        attr25.setSelected(btn);
        attr26.setSelected(btn);
        attr27.setSelected(btn);
        attr28.setSelected(btn);
        attr29.setSelected(btn);
        attr30.setSelected(btn);
        attr31.setSelected(btn);
        attr32.setSelected(btn);
        attr33.setSelected(btn);
        attr34.setSelected(btn);
        attr35.setSelected(btn);
        attr36.setSelected(btn);
        attr37.setSelected(btn);
        attr38.setSelected(btn);
        attr39.setSelected(btn);
        attr40.setSelected(btn);
        attr41.setSelected(btn);
        fetchAttr("service", attr3, 3);
        fetchAttr("flag", attr4, 4);
        fetchAttr("src_bytes", attr5, 5);
        fetchAttr("dst_bytes", attr6, 6);
        fetchAttr("land", attr7, 7);
        fetchAttr("wrong_fragment", attr8, 8);
        fetchAttr("urgent", attr9, 9);
        fetchAttr("hot", attr10, 10);
        fetchAttr("num_failed_logins", attr11, 11);
        fetchAttr("logged_in", attr12, 12);
        fetchAttr("lnum_compromised", attr13, 13);
        fetchAttr("lroot_shell", attr14, 14);
        fetchAttr("lsu_attempted", attr15, 15);
        fetchAttr("lnum_root", attr16, 16);
        fetchAttr("lnum_file_creations", attr17, 17);
        fetchAttr("lnum_shells", attr18, 18);
        fetchAttr("lnum_access_files", attr19, 19);
        fetchAttr("lnum_outbound_cmds", attr20, 20);
        fetchAttr("is_host_login", attr21, 21);
        fetchAttr("is_guest_login", attr22, 22);
        fetchAttr("count", attr23, 23);
        fetchAttr("srv_count", attr24, 24);
        fetchAttr("serror_rate", attr25, 25);
        fetchAttr("srv_serror_rate", attr26, 26);
        fetchAttr("rerror_rate", attr27, 27);
        fetchAttr("srv_rerror_rate", attr28, 28);
        fetchAttr("same_srv_rate", attr29, 29);
        fetchAttr("diff_srv_rate", attr30, 30);
        fetchAttr("srv_diff_host_rate", attr31, 31);
        fetchAttr("dst_host_count", attr32, 32);
        fetchAttr("dst_host_srv_count", attr33, 33);
        fetchAttr("dst_host_same_srv_rate", attr34, 34);
        fetchAttr("dst_host_diff_srv_rate", attr35, 35);
        fetchAttr("dst_host_same_src_port_rate", attr36, 36);
        fetchAttr("dst_host_srv_diff_host_rate", attr37, 37);
        fetchAttr("dst_host_serror_rate", attr38, 38);
        fetchAttr("dst_host_srv_serror_rate", attr39, 39);
        fetchAttr("dst_host_rerror_rate", attr40, 40);
        fetchAttr("dst_host_srv_rerror_rate", attr41, 41);
    }

    public void fetchAttr(String attr, JCheckBox e, int pos){
        takeAll.setSelected(false);
        remAll.setSelected(false);
        if(e.isSelected()){
            attrNames = (String[])ArrayUtils.removeElement(attrNames, attr);
            attrNames = (String[])ArrayUtils.add(attrNames, attr);
            attrCount += 1;
            posArr =(int[])ArrayUtils.removeElement(posArr, pos);
            posArr =(int[])ArrayUtils.add(posArr, pos);
        }else{
            attrNames = (String[])ArrayUtils.removeElement(attrNames, attr);
            attrCount -= 1;
            posArr =(int[])ArrayUtils.removeElement(posArr, pos);
        }
        status.setText("Attributes Selected: "+attrCount);
    }

    public void readIt() {
        File fileNS = new File(myDocumentPath+"original-NS.arff");
        if(fileNS.exists()) {
            fileNS.delete();
        }
        File fileS = new File(myDocumentPath+"original-S.arff");
        if(fileS.exists()) {
            fileS.delete();
        }
        File fileGA = new File(myDocumentPath+"GA-acted.arff");
        if(fileGA.exists()) {
            fileGA.delete();
        }
        File fileXi = new File(myDocumentPath+"filtered.arff");
        if(fileXi.exists()) {
            fileXi.delete();
        }
        File file1 = new File(myDocumentPath+"NS-self.arff");
        File file2 = new File(myDocumentPath+"NS-nonself.arff");
        if(file1.exists()) {
            file1.delete();
        }
        if(file2.exists()) {
            file2.delete();
        }
        File file = new File(myDocumentPath+"original.arff");
        File fileX = new File(myDocumentPath+"kddminiX.arff");
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileX));
            String line; //int lines = 0;

            while ((line = br.readLine()) != null) {
                if (line.startsWith("%")) {
                    continue;
                } else {
                    if (line.startsWith("@relation")) {
                        bw.append("\n"+line);
                        continue;
                    } else if (line.startsWith("@attribute")) {
                        String words[] = attrNames;

                        for(String word : words){
                            String sentc[] = line.split(" ");
                            String look = sentc[1];
                            if(look.equals(word)){
                                bw.append("\n"+line);
                            }
                        }
                        continue;
                    } else if (line.startsWith("@data")) {
                        if(!line.trim().equals("")) {
                            bw.append("\n"+line);
                        }
                        continue;
                    } else {
                        if (!line.trim().equals("")) {
                            String words[] = (line).trim().split(",");
                            Arrays.sort(posArr);
                            String valLine = "";

                            for(int i = 0; i < words.length; i++){
                                for(int j = 0; j < posArr.length; j++){
                                    if((i+1) == posArr[j]){
                                        if(valLine.equals(""))
                                            valLine = words[i];
                                        else
                                            valLine = valLine+","+words[i];
                                        break;
                                    }
                                }
                            }
                            bw.append("\n"+valLine);
                            continue;
                        }
                    }
                }
            }
            bw.close();
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void initReadIt() {
        File file = new File(myDocumentPath+"original.arff");
        String relation = "";
        int attr = 0;
        int data = 0;
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line; //int lines = 0;

            while ((line = br.readLine()) != null) {
                if (line.startsWith("%")) {
                    continue;
                } else {
                    if (line.startsWith("@relation")) {
                        String sentc[] = line.split(" ");
                        relation = sentc[1];
                        continue;
                    } else if(line.startsWith("@attribute")) {
                        attr++;
                        continue;
                    } else if (line.startsWith("@data")) {
                        continue;
                    } else {
                        if (!line.trim().equals("")) {
                            data++;
                            continue;
                        }
                    }
                }
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(attr < 42){
            JOptionPane.showMessageDialog(null, "ERROR: The attributes in the uploaded file is insufficient!\n\n"
                    + "Please try again with a more sufficient file!",
                    "Preprocess Error", 1, new ImageIcon("src/imgs/loaderWheel.gif"));
            System.exit(0);
        }else if(data < 250){
            JOptionPane.showMessageDialog(null, "ERROR: The instances in the uploaded file is insufficient!\n\n"
                    + "Please try again with a more sufficient file!",
                    "Preprocess Error", 1, new ImageIcon("src/imgs/loaderWheel.gif"));
            System.exit(0);
        }else if(data >= 90000){
            data = 100000;
        }
        status1.setText("Relation: "+relation+"                                   "
                + "Instances: "+data);
        System.out.println(status1.getText());
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox attr1;
    private javax.swing.JCheckBox attr10;
    private javax.swing.JCheckBox attr11;
    private javax.swing.JCheckBox attr12;
    private javax.swing.JCheckBox attr13;
    private javax.swing.JCheckBox attr14;
    private javax.swing.JCheckBox attr15;
    private javax.swing.JCheckBox attr16;
    private javax.swing.JCheckBox attr17;
    private javax.swing.JCheckBox attr18;
    private javax.swing.JCheckBox attr19;
    private javax.swing.JCheckBox attr2;
    private javax.swing.JCheckBox attr20;
    private javax.swing.JCheckBox attr21;
    private javax.swing.JCheckBox attr22;
    private javax.swing.JCheckBox attr23;
    private javax.swing.JCheckBox attr24;
    private javax.swing.JCheckBox attr25;
    private javax.swing.JCheckBox attr26;
    private javax.swing.JCheckBox attr27;
    private javax.swing.JCheckBox attr28;
    private javax.swing.JCheckBox attr29;
    private javax.swing.JCheckBox attr3;
    private javax.swing.JCheckBox attr30;
    private javax.swing.JCheckBox attr31;
    private javax.swing.JCheckBox attr32;
    private javax.swing.JCheckBox attr33;
    private javax.swing.JCheckBox attr34;
    private javax.swing.JCheckBox attr35;
    private javax.swing.JCheckBox attr36;
    private javax.swing.JCheckBox attr37;
    private javax.swing.JCheckBox attr38;
    private javax.swing.JCheckBox attr39;
    private javax.swing.JCheckBox attr4;
    private javax.swing.JCheckBox attr40;
    private javax.swing.JCheckBox attr41;
    private javax.swing.JCheckBox attr42;
    private javax.swing.JCheckBox attr5;
    private javax.swing.JCheckBox attr6;
    private javax.swing.JCheckBox attr7;
    private javax.swing.JCheckBox attr8;
    private javax.swing.JCheckBox attr9;
    private javax.swing.JLabel backBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel next;
    private javax.swing.JCheckBox remAll;
    private javax.swing.JLabel status;
    private javax.swing.JLabel status1;
    private javax.swing.JCheckBox takeAll;
    // End of variables declaration//GEN-END:variables

}