/*
 * detectProcess.java
 * Creates the graphical representation of the first
 * 10 detected data match
 *
 * Created on 29-Dec-2016, 19:45:11
 */

package frames;

/**
 *
 * @author DeGod
 */

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.experimental.chart.plot.CombinedCategoryPlot;
import org.jfree.ui.ApplicationFrame;

public class showGraph extends ApplicationFrame {

    public showGraph(String title, int data1[], double data2) {
        super(title);
        JPanel chartPanel = createDemoPanel(data1, data2);
        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
        setContentPane(chartPanel);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((dim.width/2-this.getSize().width/2)-150, (dim.height/2-this.getSize().height/2)-150);
    }

    public static CategoryDataset createDataset1(int data1[], double data2) {
        DefaultCategoryDataset result = new DefaultCategoryDataset();
        String series1 = "Manhattan Distance Detection per second";
//        String type[] = {"","","","","","","","","",""};
        String[] time = {
            String.valueOf(data2*0.1),
            String.valueOf(data2*0.2),
            String.valueOf(data2*0.3),
            String.valueOf(data2*0.4),
            String.valueOf(data2*0.5),
            String.valueOf(data2*0.6),
            String.valueOf(data2*0.7),
            String.valueOf(data2*0.8),
            String.valueOf(data2*0.9),
            String.valueOf(data2*1)
        };

        for(int i = 0; i < data1.length; i++){
            result.addValue(data1[i], series1, time[i]);
        }
        return result;
    }

    private static JFreeChart createChart(int data1[], double data2) {
        CategoryDataset dataset1 = createDataset1(data1, data2);
        NumberAxis rangeAxis1 = new NumberAxis("Value");
        rangeAxis1.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        LineAndShapeRenderer renderer1 = new LineAndShapeRenderer();
        renderer1.setBaseToolTipGenerator(new StandardCategoryToolTipGenerator());
        CategoryPlot subplot1 = new CategoryPlot(dataset1, null, rangeAxis1, renderer1);
        subplot1.setDomainGridlinesVisible(true);

        CategoryAxis domainAxis = new CategoryAxis("TIME (in seconds)");
        CombinedCategoryPlot plot = new CombinedCategoryPlot(domainAxis, new NumberAxis("NONSELFs DETECTED"));
        plot.add(subplot1, 2);

        JFreeChart result = new JFreeChart("MANHATTAN DISTANCE DETECTION TOP 10 MATCHES",
                new Font("SansSerif", Font.BOLD, 12), plot, true);
        return result;
    }

    public static JPanel createDemoPanel(int data1[], double data2) {
        JFreeChart chart = createChart(data1, data2);
        return new ChartPanel(chart);
    }
}
