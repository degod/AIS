/*
 * detectProcess.java
 * Does the segregation of the:
 *  ==> Normal (Data labelled 'normal' at the 42nd attribute)
 *  ==> Abnormal (Data labelled anything other than 'normal' at the 42nd attribute)
 *
 * ... on the original.arff to produce the "original-NS.arff"
 * and does a comparison with the "NS-nonself.arff" file to see 
 * where there is a match.
 *
 * Created on 29-Dec-2016, 08:45:11
 */

package frames;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

/**
 *
 * @author DeGod
 */
public class detectProcess {

    String myDocumentPath = System.getProperty("user.home") + "\\Documents\\AIS\\";
    
    public void filter() {
        File file = new File(myDocumentPath+"kddminiX.arff");
        File fileX = new File(myDocumentPath+"filtered.arff");
        if(fileX.exists() && !fileX.isDirectory()) {
            fileX.delete();
        }
        fileX = new File(myDocumentPath+"filtered.arff");
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileX));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("%")) {
                    continue;
                } else {
                    if (line.startsWith("@relation")) {
                        continue;
                    } else if (line.startsWith("@attribute")) {
                        continue;
                    } else if (line.startsWith("@data")) {
                        continue;
                    } else {
                        if (!line.trim().equals("")) {
                            if (!line.trim().equals("")) {
                                bw.append("\n" + line);
                            }
                            continue;
                        }
                    }
                }
            }
            bw.close();
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void segregate(){
        filter();
        File fileX = new File(myDocumentPath+"filtered.arff");
        File file1 = new File(myDocumentPath+"self.arff");
        File file2 = new File(myDocumentPath+"nonself.arff");
        if(file1.exists() && !file1.isDirectory()) {
            file1.delete();
        }
        if(file2.exists() && !file2.isDirectory()) {
            file2.delete();
        }
        file1 = new File(myDocumentPath+"self.arff");
        file2 = new File(myDocumentPath+"nonself.arff");
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileX));
            BufferedWriter bw1 = new BufferedWriter(new FileWriter(file1));
            BufferedWriter bw2 = new BufferedWriter(new FileWriter(file2));
            String line;
            while((line = br.readLine()) != null) {
                if(!line.trim().equals("")){
                    line = line.replaceAll(",", " ");
                    String data[] = line.split(" ");
                    if(data[data.length-1].equalsIgnoreCase("normal")) {
                        bw1.append("\n" + line);
                        continue;
                    } else {
                        bw2.append("\n" + line);
                        continue;
                    }
                }
            }
            bw1.close();
            bw2.close();
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        rejoinFiles();
    }

    public void rejoinFiles(){
        File file = new File(myDocumentPath+"kddminiX.arff");
        File file1 = new File(myDocumentPath+"original-S.arff");
        File file2 = new File(myDocumentPath+"original-NS.arff");
        if(file1.exists() && !file1.isDirectory()) {
            file1.delete();
        }
        if(file2.exists() && !file2.isDirectory()) {
            file2.delete();
        }
        file1 = new File(myDocumentPath+"original-S.arff");
        file2 = new File(myDocumentPath+"original-NS.arff");
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            BufferedWriter bw1 = new BufferedWriter(new FileWriter(file1));
            BufferedWriter bw2 = new BufferedWriter(new FileWriter(file2));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("@relation")) {
                    if(!line.trim().equals("")) {
                        bw1.append("\n"+line);
                        bw2.append("\n"+line);
                    }
                    continue;
                }else if (line.startsWith("@attribute")) {
                    if(!line.trim().equals("")) {
                        bw1.append("\n"+line);
                        bw2.append("\n"+line);
                    }
                    continue;
                } else if (line.startsWith("@data")) {
                    if(!line.trim().equals("")) {
                        bw1.append("\n"+line);
                        bw2.append("\n"+line);
                    }
                    break;
                }
            }
            bw1.append("\n");
            bw2.append("\n");
            bw1.close();
            bw2.close();
            br.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        File fileX1 = new File(myDocumentPath+"self.arff");
        File fileX2 = new File(myDocumentPath+"nonself.arff");
        try {
            BufferedReader br1 = new BufferedReader(new FileReader(fileX1));
            BufferedReader br2 = new BufferedReader(new FileReader(fileX2));
            BufferedWriter bw1 = new BufferedWriter(new FileWriter(file1, true));
            BufferedWriter bw2 = new BufferedWriter(new FileWriter(file2, true));
            String line1, line2;
            while((line1 = br1.readLine()) != null){
                bw1.append("\n"+line1);
            }
            while((line2 = br2.readLine()) != null){
                bw2.append("\n"+line2);
            }
            bw1.close();
            bw2.close();
            br1.close();
            br2.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        File filex1 = new File(myDocumentPath+"self.arff");
        File filex2 = new File(myDocumentPath+"nonself.arff");
        if(filex1.exists() && !filex1.isDirectory()) {
            filex1.delete();
        }
        if(filex2.exists() && !filex2.isDirectory()) {
            filex2.delete();
        }
    }
}