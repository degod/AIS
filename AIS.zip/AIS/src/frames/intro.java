/*
 * intro.java
 * Initiates the program from splashScreen
 *
 * Created on 18-Dec-2016, 21:40:58
 */

package frames;

import java.io.File;

/**
 *
 * @author DeGod
 */
public class intro{

    public static void main(String asd[]){
        String myDocumentPath = System.getProperty("user.home") + "\\Documents\\AIS";
        try{
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }

            Thread.sleep(3000);
            Cover uf = new Cover();
            uf.setVisible(true);
        }catch(Exception e){
            e.printStackTrace();
        }
        new intro();
    }
}
