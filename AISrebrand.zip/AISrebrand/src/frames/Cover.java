package frames;

import java.awt.*;
import javax.swing.ImageIcon;

public class Cover extends javax.swing.JFrame implements Runnable
{

    Thread t;

    public Cover() {
        initComponents();
        t = new Thread(this);
        t.start();
        Dimension scr = Toolkit.getDefaultToolkit().getScreenSize();
        this.setSize(scr);
        setIconImage(new ImageIcon("src/imgs/aisFav.png").getImage());
    }

    public void run()
    {
        try{
            t.sleep(1);
            new uploadFile().setVisible(true);
        }catch(Exception g){}
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("FLEXIBLE EXAMINATION ENGINE...");
        setEnabled(false);
        setUndecorated(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 464, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 319, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

}
