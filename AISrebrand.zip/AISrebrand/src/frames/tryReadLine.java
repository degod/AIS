package frames;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Arrays;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class tryReadLine extends javax.swing.JFrame {

    String relation, attribute[] = new String[0];
    int data, count = 1;

    public tryReadLine() {
        initComponents();
        peniel.setLayout(new GridLayout(0, 1));
    }

    public void readIt() {
        File file = new File("src/file/original.arff");
        File fileX = new File("src/file/kddminiX.arff");
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileX));
            String line;
            while ((line = br.readLine()) != null) {
                // process the line.
                if (line.startsWith("%")) {
                    continue;
                } else {
                    if (line.startsWith("@relation")) {
                        String[] words = line.split(" ");
                        relation = words[1];
                        if(!line.trim().equals("")) {
                            bw.append("\n"+line);
                        }
                        continue;
                    } else if (line.startsWith("@attribute")) {
                        String[] words = line.split(" ");
                        int z = attribute.length;
                        attribute = Arrays.copyOf(attribute, z + 1);
                        attribute[z] = words[1];
                        if(!line.trim().equals("")) {
                            bw.append("\n"+line);
                        }
                        continue;
                    } else if (line.startsWith("@data")) {
                        if(!line.trim().equals("")) {
                            bw.append("\n"+line);
                        }
                        continue;
                    } else {
                        if (!line.trim().equals("")) {
                            data += 1;
                            if(!line.trim().equals("")) {
                                bw.append("\n"+line);
                            }
                            continue;
                        }
                    }
                }
            }
            bw.close();
            br.close();
            display.append("Relation: \t" + relation);
            display.append("\nAttributes: \t" + attribute.length);
            for (int i = 0; i < attribute.length; i++) {
                display.append("\n=====>> \t" + attribute[i]);
            }
            display.append("\nInstances: \t" + data);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        display = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        peniel = new javax.swing.JPanel();
        addComp = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        tell = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("Re-Order file");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        display.setColumns(20);
        display.setLineWrap(true);
        display.setRows(5);
        display.setWrapStyleWord(true);
        jScrollPane1.setViewportView(display);

        javax.swing.GroupLayout penielLayout = new javax.swing.GroupLayout(peniel);
        peniel.setLayout(penielLayout);
        penielLayout.setHorizontalGroup(
            penielLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 241, Short.MAX_VALUE)
        );
        penielLayout.setVerticalGroup(
            penielLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 315, Short.MAX_VALUE)
        );

        jScrollPane2.setViewportView(peniel);

        addComp.setText("Add Component");
        addComp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addCompActionPerformed(evt);
            }
        });

        jLabel1.setText("jLabel1");

        tell.setText("Tell");
        tell.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tellActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tell)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(addComp)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 317, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 317, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(addComp, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
                        .addComponent(tell, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE))
                .addGap(16, 16, 16))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        readIt();
        JOptionPane.showMessageDialog(null, "Done writing!!!");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void addCompActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addCompActionPerformed
        // TODO add your handling code here:
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                peniel.add(new JCheckBox("CheckBox"+count));
                peniel.validate();
                peniel.repaint();
            }
        });
        count++;
    }//GEN-LAST:event_addCompActionPerformed

    public void chkActionPerformed(ActionEvent e) {
        if(e.getSource() == "") {
        }
    }

    private void tellActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tellActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tellActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new tryReadLine().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addComp;
    private javax.swing.JTextArea display;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel peniel;
    private javax.swing.JButton tell;
    // End of variables declaration//GEN-END:variables
}
