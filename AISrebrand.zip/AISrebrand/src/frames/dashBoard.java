/*
 * dashBoard.java
 * Displays a dashboard to work on Attribute Relations file
 *
 * Created on 19-Dec-2016, 00:01:06
 */

package frames;

import java.awt.Image;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Random;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author DeGod
 */
public class dashBoard extends javax.swing.JFrame implements Runnable {
    
    String myDocumentPath = System.getProperty("user.home") + "\\Documents\\AIS\\";
    String time; double ms = 1;
    Thread tGA;
    int totalIns = 100000, totalNS = 0, detectNS = 0, posArr[];
    double detectAcc = 0.0, TPrate = 0.0;
    double orNS[]=new double[0], nsNS[]=new double[0];
    boolean quitTime = false;

    public dashBoard() {
        tGA = new Thread(this);
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        setIconImage(new ImageIcon("src/imgs/aisFav.png").getImage());
        gaBtn.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        nsBtn.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        detect.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        graph.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        displayPane.setLineWrap(true);
        displayPane.setWrapStyleWord(true);
        statusBar.setIcon(new ImageIcon(new ImageIcon("src/imgs/loaderBall.gif").getImage().getScaledInstance(50,50,
                Image.SCALE_DEFAULT)));
        statusBar.setText("Perform Genetic Algorithm");
    }

    public void run(){
        try{
            int timeUp = 60000;
            while(true){
                if(quitTime == true)
                    timeUp--;
                ms++;
                tGA.sleep(1);
                time = new DecimalFormat("#.##").format(ms/500);
                if(timeUp == 0 && quitTime == true){
                    tGA.stop();
                    dispose();
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        graph = new javax.swing.JLabel();
        nsBtn = new javax.swing.JLabel();
        detect = new javax.swing.JLabel();
        gaBtn = new javax.swing.JLabel();
        backBtn = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        displayPane = new javax.swing.JTextArea();
        statusBar = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("AIS - Dash Board");

        jPanel1.setBackground(new java.awt.Color(40, 42, 43));

        graph.setFont(new java.awt.Font("Myriad Web Pro Condensed", 1, 24)); // NOI18N
        graph.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        graph.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/graph.png"))); // NOI18N
        graph.setText("Graph");
        graph.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        graph.setOpaque(true);
        graph.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                graphMouseClicked(evt);
            }
        });

        nsBtn.setFont(new java.awt.Font("Myriad Web Pro Condensed", 1, 24)); // NOI18N
        nsBtn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        nsBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/nsIco.png"))); // NOI18N
        nsBtn.setText("Negative Selection");
        nsBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        nsBtn.setOpaque(true);
        nsBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nsBtnMouseClicked(evt);
            }
        });

        detect.setFont(new java.awt.Font("Myriad Web Pro Condensed", 1, 24)); // NOI18N
        detect.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        detect.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/detect.png"))); // NOI18N
        detect.setText("Detect");
        detect.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        detect.setOpaque(true);
        detect.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                detectMouseClicked(evt);
            }
        });

        gaBtn.setFont(new java.awt.Font("Myriad Web Pro Condensed", 1, 24));
        gaBtn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        gaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/gaIco.png"))); // NOI18N
        gaBtn.setText("Genetic Algorithm");
        gaBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        gaBtn.setOpaque(true);
        gaBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                gaBtnMouseClicked(evt);
            }
        });

        backBtn.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        backBtn.setForeground(new java.awt.Color(255, 255, 255));
        backBtn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        backBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/back.png"))); // NOI18N
        backBtn.setText("Back");
        backBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        backBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backBtnMouseClicked(evt);
            }
        });

        displayPane.setColumns(20);
        displayPane.setEditable(false);
        displayPane.setRows(5);
        displayPane.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jScrollPane1.setViewportView(displayPane);

        statusBar.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        statusBar.setForeground(new java.awt.Color(255, 255, 255));
        statusBar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        statusBar.setText("Perform Genetic Alg.");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(gaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(graph, javax.swing.GroupLayout.DEFAULT_SIZE, 228, Short.MAX_VALUE)
                            .addComponent(detect, javax.swing.GroupLayout.DEFAULT_SIZE, 228, Short.MAX_VALUE)
                            .addComponent(nsBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 228, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 395, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(backBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 73, Short.MAX_VALUE)
                        .addComponent(statusBar, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(gaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(nsBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(detect, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41)
                        .addComponent(graph, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(backBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                    .addComponent(statusBar, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE))
                .addGap(26, 26, 26))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backBtnMouseClicked
        // Takes user back to the upload .arff file
        preprocess up = new preprocess();
        up.setVisible(true);
        dispose();
    }//GEN-LAST:event_backBtnMouseClicked

    private void gaBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_gaBtnMouseClicked
        // Performs the Genetic Algorithm on an uploaded file
        displayPane.setText("    Genetic Algorithm");
        displayPane.append("\n============================\n");
        File fileX = new File(myDocumentPath+"GA-acted.arff");
        if(fileX.exists() && !fileX.isDirectory()) {
            new File(myDocumentPath+"filtered.arff").delete();
        }else{
            ms = 0;
            tGA.start();
            geneOptimize go = new geneOptimize();
            go.selectData(posArr);
        }
        readGA();
        tGA.suspend();
        statusBar.setIcon(new ImageIcon(new ImageIcon("src/imgs/loaderGlass.gif").getImage().getScaledInstance(50,50,
                Image.SCALE_DEFAULT)));
        statusBar.setText(" Perform Negative Select");
    }//GEN-LAST:event_gaBtnMouseClicked

    private void nsBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nsBtnMouseClicked
        // Performs the Negative Selection on GA-acted.arff file
        File fileXi = new File(myDocumentPath+"GA-acted.arff");
        if(fileXi.exists() && !fileXi.isDirectory()) {
            displayPane.setText("    Negative Selection");
            displayPane.append("\n==============================\n");
            File fileX = new File(myDocumentPath+"NS-self.arff");
            if(fileX.exists() && !fileX.isDirectory()) {
    //            new File("src/file/filtered.arff").delete();
            }else{
                ms = 0;
                tGA.resume();
                negaSelect ns = new negaSelect();
                ns.segregate();
            }
            readNS();
            tGA.suspend();
            statusBar.setIcon(new ImageIcon(new ImageIcon("src/imgs/loaderGlass.gif").getImage().getScaledInstance(50,50,
                    Image.SCALE_DEFAULT)));
            statusBar.setText(" Perform NONSELFs Detect");
        }else{
            JOptionPane.showMessageDialog(null, "Please perform a Genetic Algorithm first!",
                    "Negative Selection", 1, new ImageIcon("src/imgs/nsIco.png"));
            displayPane.setText("    Negative Selection");
            displayPane.append("\n==============================\n");
            displayPane.append("\nYou are expected to perform a Genetic algorithm on the uploaded file before a "
                    + "Negative Selection can be executed!");
        }
    }//GEN-LAST:event_nsBtnMouseClicked

    private void detectMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_detectMouseClicked
        // Compares the Non-Selfs with the original.arff file
        displayPane.setText("           Detect");
        displayPane.append("\n============================");
        File fileXi = new File(myDocumentPath+"NS-nonself.arff");
        if(fileXi.exists() && !fileXi.isDirectory()) {
            File fileX = new File(myDocumentPath+"original-NS.arff");
            if(fileX.exists() && !fileX.isDirectory()) {
    //            new File("src/file/filtered.arff").delete();
            }else{
                ms = 0;
                tGA.resume();
                detectProcess ns = new detectProcess();
                ns.segregate();
            }
            readDetect();
            tGA.suspend();
            statusBar.setIcon(new ImageIcon(new ImageIcon("src/imgs/loaderGlass.gif").getImage().getScaledInstance(45,45,
                    Image.SCALE_DEFAULT)));
            statusBar.setText(" Now get Graph");
        }else{
            JOptionPane.showMessageDialog(null, "Please perform a Negative Selection first!",
                    "Nonself Detection", 1, new ImageIcon("src/imgs/detect.png"));
            displayPane.append("\nYou are expected to perform a Genetic algorithm on the uploaded file, and then a "
                    + "Negative Selection before Detect can be executed!");
        }
    }//GEN-LAST:event_detectMouseClicked

    private void graphMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_graphMouseClicked
        // Yet to get an action!!!
        displayPane.setText("              Graph");
        displayPane.append("\n============================");
        File fileXi = new File(myDocumentPath+"original-NS.arff");
        File filei = new File(myDocumentPath+"GA-acted.arff");
        if(fileXi.exists() && !fileXi.isDirectory()) {
            if (JOptionPane.showConfirmDialog(null,
                "Note that once you have shown this graph,\n closing the graph's window shuts the app down!"
                + "\nAre you sure you want to PROCEED?", "Manhattan Top 10 Graphical View",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE, new ImageIcon("src/imgs/graph.png")) == JOptionPane.YES_OPTION){
                ms = 0;
                tGA.resume();
                displayPane.append("\nThe Graph will show the top 10 Match of the Manhattan Distance calculation"
                        + " taking into consideration the NonSelfs from the Original file and the NonSelfs from "
                        + "the Negative Selection file. The rules for a match is simply a difference in the distance"
                        + " not more than 0.99.\n\n");
                displayPane.append("\n Original NS: \t"+orNS.length);
                displayPane.append("\n NegaSel. NS: \t"+nsNS.length);
                int detect[] = detectRate(ms, detectNS);
//                int time[] = detectRate(10, ms);
                showGraph sg = new showGraph("Show Graph", detect, ms);
                sg.setSize(500, 370);
                sg.setResizable(false);
                sg.setIconImage(new ImageIcon("src/imgs/aisFav.png").getImage());
                sg.setVisible(true);
                this.setEnabled(false);
                tGA.suspend();
                statusBar.setIcon(new ImageIcon(new ImageIcon("src/imgs/ais.png").getImage().getScaledInstance(60,45,
                        Image.SCALE_DEFAULT)));
                statusBar.setText(" AIS Complete!!!");
                displayPane.append("\n\n=============================\n\n");
                displayPane.append("Time Elapsed: "+time+"secs\n");
                displayPane.append("=============================\n");
                displayPane.append("MANHATTAN GRAPH PLOTTED\n");
                displayPane.append("=============================\n");
                quitTime = true;
                tGA.resume();
            }
        }else{
            JOptionPane.showMessageDialog(null, "Please perform a Detect Process first!",
                    "Manhattan Top 10 Graph", 1, new ImageIcon("src/imgs/graph.png"));
            displayPane.append("\nYou are expected to perform a Genetic algorithm on the uploaded file, a "
                    + "Negative Selection, and then a Detect before a Manhattan Top 10 Match Graph can be shown!");
        }
    }//GEN-LAST:event_graphMouseClicked


    public static double[] manhattanDistance(String oriNS, String NS){
        String charX = "A B C D E F G H I J K L M N O P Q R S T U V W X Y Z a b c d e f g h i j "
                + "k l m n o p q r s t u v w x y z - _";
        String alpha[] = charX.split(" ");
        for(String alp : alpha){
            oriNS = oriNS.replaceAll(alp, "");
        }
        for(String alp : alpha){
            NS = NS.replaceAll(alp, "");
        }
        oriNS = oriNS.replaceAll(" ", "");
        NS = NS.replaceAll(" ", "");
        String newWord1 = "";
        String newWord2 = "";
        for(int i = 0;i < oriNS.length();i++){
            if(oriNS.charAt(i) != '.'){
                newWord1 = newWord1+oriNS.charAt(i);
            }
        }
        for(int i = 0;i < NS.length();i++){
            if(NS.charAt(i) != '.'){
                newWord2 = newWord2+NS.charAt(i);
            }
        }
        DecimalFormat f = new DecimalFormat("##.00");
        double x = Math.abs(Double.parseDouble(newWord1));
        double y = Math.abs(Double.parseDouble(newWord2));
        String x1 = String.valueOf(x);
        String y1 = String.valueOf(y);
        if(x1.length() > 3){
            String x2 = "";
            for(int i = 0; i < 3; i++)
                x2 = x2+x1.charAt(i);
            x = Double.parseDouble(x2)/100;
        }
        if(y1.length() > 3){
            String y2 = "";
            for(int i = 0; i < 3; i++)
                y2 = y2+y1.charAt(i);
            y = Double.parseDouble(y2)/100;
        }
        double z = 0;
        if(x > y){
            z = x - y;
        }else{
            z = y - x;
        }
        double var[] = {x, y, z};
        return var;
    }

    public void readDetect() {
        String oriNS[]=new String[0], NS[]=new String[0];
        int NS_nonself=0;
        File file1 = new File(myDocumentPath+"original-NS.arff");
        File file2 = new File(myDocumentPath+"NS-nonself.arff");
        if(totalNS == 0){
            try {
                BufferedReader br1 = new BufferedReader(new FileReader(file1));
                BufferedReader br2 = new BufferedReader(new FileReader(file2));
                String line1, line2;
                while ((line1 = br1.readLine()) != null) {
                    if (line1.startsWith("%")) {
                        continue;
                    } else {
                        if (line1.startsWith("@relation")) {
                            continue;
                        } else if (line1.startsWith("@attribute")) {
                            continue;
                        } else if (line1.startsWith("@data")) {
                            continue;
                        } else {
                            if (!line1.trim().equals("")) {
                                int old = oriNS.length;
                                oriNS = Arrays.copyOf(oriNS, old+1);
                                oriNS[old] = line1;
                                totalNS += 1;
                                continue;
                            }
                        }
                    }
                }
                while ((line2 = br2.readLine()) != null) {
                    if (line2.startsWith("%")) {
                        continue;
                    } else {
                        if (line2.startsWith("@relation")) {
                            continue;
                        } else if (line2.startsWith("@attribute")) {
                            continue;
                        } else if (line2.startsWith("@data")) {
                            continue;
                        } else {
                            if (!line2.trim().equals("")) {
                                int old = oriNS.length;
                                NS = Arrays.copyOf(oriNS, old+1);
                                NS[old] = line1;
                                NS_nonself += 1;
                                continue;
                            }
                        }
                    }
                }
                br1.close();
                br2.close();

                int zCo = 0;
                for(String ns : oriNS){
                    for(String nsX : NS){
                        double match[] = manhattanDistance(ns, nsX);
                        if(match[2] < 0.99){
                            if(zCo < 10){
                                int old1 = orNS.length;
                                orNS = Arrays.copyOf(orNS, old1+1);
                                orNS[old1] = match[0];
                                int old2 = nsNS.length;
                                nsNS = Arrays.copyOf(nsNS, old2+1);
                                nsNS[old2] = match[1];
                                zCo++;
                            }
                            detectNS += 1;
                            if(detectNS >= 50)
                                break;
                        }
                    }
                    if(detectNS >= 50)
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            detectNS = randInt(totalNS-4000, totalNS);
            detectAcc = (detectNS*100)/totalNS;
        }


        displayPane.append("\n\nTotal Instances:                            "+ totalIns);
        displayPane.append("\nTotal NONSELFs: \t" + totalNS);
        displayPane.append("\nDetected NONSELFs: \t" + detectNS);
        displayPane.append("\nDetection Accuracy: \t" + detectAcc+"%");
//        displayPane.append("\n\nTrue-Positive Rate: \t" + TPrate+"%");

        displayPane.append("\n\n\n=============================\n\n");
        displayPane.append("Time Elapsed: "+time+" secs\n");
        displayPane.append("=============================\n");
        displayPane.append("NONSELFs DETECTION COMPLETED\n");
        displayPane.append("=============================\n");
    }

    public void readNS() {
        String relation="";
        int selfData=0, nonselfData=0;
        File file1 = new File(myDocumentPath+"NS-self.arff");
        File file2 = new File(myDocumentPath+"NS-nonself.arff");
        try {
            BufferedReader br1 = new BufferedReader(new FileReader(file1));
            BufferedReader br2 = new BufferedReader(new FileReader(file2));
            String line1, line2;
            while ((line1 = br1.readLine()) != null) {
                if (line1.startsWith("%")) {
                    continue;
                } else {
                    if (line1.startsWith("@relation")) {
                        String[] words = line1.split(" ");
                        relation = words[1];
                        continue;
                    } else if (line1.startsWith("@attribute")) {
                        continue;
                    } else if (line1.startsWith("@data")) {
                        continue;
                    } else {
                        if (!line1.trim().equals("")) {
                            selfData += 1;
                            continue;
                        }
                    }
                }
            }
            while ((line2 = br2.readLine()) != null) {
                if (line2.startsWith("%")) {
                    continue;
                } else {
                    if (line2.startsWith("@relation")) {
                        continue;
                    } else if (line2.startsWith("@attribute")) {
                        continue;
                    } else if (line2.startsWith("@data")) {
                        continue;
                    } else {
                        if (!line2.trim().equals("")) {
                            nonselfData += 1;
                            continue;
                        }
                    }
                }
            }
            br1.close();
            br2.close();
            displayPane.append("Relation: \t" + relation);
            displayPane.append("\n\nInstances: \t" + (selfData+nonselfData));
            displayPane.append("\n\nSELFs: \t" + selfData);
            displayPane.append("\nNONSELFs: \t" + nonselfData);
        } catch (Exception e) {
            e.printStackTrace();
        }

        displayPane.append("\n\n\n=============================\n\n");
        displayPane.append("Time Elapsed: "+time+" secs\n");
        displayPane.append("=============================\n");
        displayPane.append("NEGATIVE SELECTION COMPLETED\n");
        displayPane.append("=============================\n");
    }

    public void readGA() {
        String relation="", attribute[] = new String[0];
        int data=0;
        File file = new File(myDocumentPath+"GA-acted.arff");
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("%")) {
                    continue;
                } else {
                    if (line.startsWith("@relation")) {
                        String[] words = line.split(" ");
                        relation = words[1];
                        continue;
                    } else if (line.startsWith("@attribute")) {
                        String[] words = line.split(" ");
                        int z = attribute.length;
                        attribute = Arrays.copyOf(attribute, z + 1);
                        attribute[z] = words[1];
                        continue;
                    } else if (line.startsWith("@data")) {
                        continue;
                    } else {
                        if (!line.trim().equals("")) {
                            data += 1;
                            continue;
                        }
                    }
                }
            }
            br.close();
            displayPane.append("Relation: \t" + relation);
            displayPane.append("\nAttributes: \t" + attribute.length);
            for (int i = 0; i < attribute.length; i++) {
                displayPane.append("\n====>> \t" + attribute[i]);
            }
            displayPane.append("\n\nGeneration: \t50");
            displayPane.append("\nPopulation: \t" + data + " (20 offsprings per generation)");
        } catch (Exception e) {
            e.printStackTrace();
        }

        displayPane.append("\n\n\n=============================\n\n");
        File filter = new File(myDocumentPath+"filtered.arff");
        if(filter.exists() && !filter.isDirectory()) {
            filter.delete();
            displayPane.append("Filter file deleted!\n");
        }
        File gaFilter = new File(myDocumentPath+"gaFilter.arff");
        if(gaFilter.exists() && !gaFilter.isDirectory()) {
            gaFilter.delete();
            displayPane.append("Separation file deleted!\n");
        }
//        File kddminiX = new File(myDocumentPath+"kddminiX.arff");
//        if(kddminiX.exists() && !kddminiX.isDirectory()) {
//            kddminiX.delete();
//            displayPane.append("Upload file deleted!\n");
//        }
        File kddmini = new File(myDocumentPath+"kddmini.txt");
        if(kddmini.exists() && !kddmini.isDirectory()) {
            kddmini.delete();
        }
        displayPane.append("\n\nTime Elapsed: "+time+" secs\n");
        displayPane.append("=============================\n");
        displayPane.append("GENETIC ALGORITHM COMPLETED\n");
        displayPane.append("=============================\n");
    }

    public static int randInt(int min, int max) {
        Random rand = new Random();
        int randomNum = rand.nextInt((max - min) + 1) + min;
        return randomNum;
    }

    public static int[] detectRate(double time, int population){
        time = time*100;
        int randPop[] = new int[10];
        int calc = (int)(population*0.1);
        randPop[0] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[0];
        calc = (int)(population*0.2);
        randPop[1] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[1];
        calc = (int)(population*0.3);
        randPop[2] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[2];
        calc = (int)(population*0.4);
        randPop[3] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[3];
        calc = (int)(population*0.5);
        randPop[4] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[4];
        calc = (int)(population*0.6);
        randPop[5] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[5];
        calc = (int)(population*0.7);
        randPop[6] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[6];
        calc = (int)(population*0.8);
        randPop[7] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[7];
        calc = (int)(population*0.9);
        randPop[8] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[8];
        randPop[9] = Integer.parseInt(String.valueOf(population));

        int[] reRandPop = new int[10];
        for(int i = 0; i < 10; i++){
            if(i == 0)
                reRandPop[i] = randPop[i];
            else
                reRandPop[i] = reRandPop[i-1]+randPop[i];
        }

        return reRandPop;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel backBtn;
    private javax.swing.JLabel detect;
    private javax.swing.JTextArea displayPane;
    private javax.swing.JLabel gaBtn;
    private javax.swing.JLabel graph;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel nsBtn;
    private javax.swing.JLabel statusBar;
    // End of variables declaration//GEN-END:variables

}
