package frames;

import java.text.DecimalFormat;
import java.util.Random;
import org.apache.commons.lang3.StringUtils;
//import org.jfree.ui.RefineryUtilities;

public class testRand {

    public static int randInt(int min, int max) {
        Random rand = new Random();
        int randomNum = rand.nextInt((max - min) + 1) + min;
        return randomNum;
    }

    public static int[] detectRate(double time, int population){
        time = time*100;
        int randPop[] = new int[10];
        int calc = (int)(population*0.1);
        randPop[0] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[0];
        calc = (int)(population*0.2);
        randPop[1] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[1];
        calc = (int)(population*0.3);
        randPop[2] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[2];
        calc = (int)(population*0.4);
        randPop[3] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[3];
        calc = (int)(population*0.5);
        randPop[4] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[4];
        calc = (int)(population*0.6);
        randPop[5] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[5];
        calc = (int)(population*0.7);
        randPop[6] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[6];
        calc = (int)(population*0.8);
        randPop[7] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[7];
        calc = (int)(population*0.9);
        randPop[8] = randInt(Integer.parseInt(String.valueOf(calc/2)), calc);
        population = population - randPop[8];
        randPop[9] = Integer.parseInt(String.valueOf(population));

        int[] reRandPop = new int[10];
        for(int i = 0; i < 10; i++){
            if(i == 0)
                reRandPop[i] = randPop[i];
            else
                reRandPop[i] = reRandPop[i-1]+randPop[i];
        }
        
        return reRandPop;
    }

    public static String randDoub(double min, double max) {
        double random = new Random().nextDouble();
        double result = min + (random * (max - min));
        DecimalFormat f = new DecimalFormat("##.00");
        return f.format(result);
    }

    public static double[] manhattanDistance(String oriNS, String NS){
        String charX = "A B C D E F G H I J K L M N O P Q R S T U V W X Y Z a b c d e f g h i j "
                + "k l m n o p q r s t u v w x y z";
        String alpha[] = charX.split(" ");
        for(String alp : alpha){
            oriNS = oriNS.replaceAll(alp, "");
        }
        for(String alp : alpha){
            NS = NS.replaceAll(alp, "");
        }
        oriNS = oriNS.replaceAll(" ", "");
        NS = NS.replaceAll(" ", "");
        String newWord1 = "";
        String newWord2 = "";
        for(int i = 0;i < oriNS.length();i++){
            if(oriNS.charAt(i) != '.'){
                newWord1 = newWord1+oriNS.charAt(i);
            }
        }
        for(int i = 0;i < NS.length();i++){
            if(NS.charAt(i) != '.'){
                newWord2 = newWord2+NS.charAt(i);
            }
        }
        DecimalFormat f = new DecimalFormat("##.00");
        double x = Double.parseDouble(StringUtils.stripStart(newWord1, "0"))/1000000;
        double y = Double.parseDouble(StringUtils.stripStart(newWord2, "0"))/1000000;
        String x1 = String.valueOf(x);
        String y1 = String.valueOf(y);
        if(x1.length() > 3){
            String x2 = "";
            for(int i = 0; i < 3; i++)
                x2 = x2+x1.charAt(i);
            x = Double.parseDouble(x2)/100;
        }
        if(y1.length() > 3){
            String y2 = "";
            for(int i = 0; i < 3; i++)
                y2 = y2+y1.charAt(i);
            y = Double.parseDouble(y2)/100;
        }
        double z = 0;
        if(x > y){
            z = x - y;
        }else{
            z = y - x;
        }
        double var[] = {x, y, z};
        return var;
    }

    public static void main(String[] ds){
        int d = randInt(10, 79);
        int clubsArray[] = {3,5,6,2,8,1,7,9,4};
        String fer[] = {"Dog","Cat","Vet","Ant"};

//        String arr = fer[new Random().nextInt(fer.length)];
//        int z = clubsArray[new Random().nextInt(clubsArray.length)];
//
//        String num = randDoub(1.00, 1.99);
//        String word1 = "0 icmp SF 0 0 0 0 0 0.00 255 0.00 0.00 0.00 smurf";
//        String word2 = "0 tcp RSTR 0 0 0 0 0 0.00 1 0.00 0.99 1.00 portsweep";
//        double md[] = manhattanDistance(word1, word2);
//        testGraph tg = new testGraph("Graph");
//        tg.setSize(500, 370);
//        tg.setVisible(true);
        System.out.println("Time: 12.75");
        System.out.println("Population: 33265\n\n");
        int[] dog = detectRate(12.75, 33265);
        int cat = 0;
        for(int i = 0; i < dog.length; i++){
            System.out.println(dog[i]);
            cat += dog[i];
        }System.out.println("\n\nTotal:  "+cat);
    }
}
